<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sitemap_model extends CI_Model {

    public function getUrls() {
        // Fetch URLs from the database
        return $this->db->select('slug, updated_at')
                        ->from('pages') // Replace 'pages' with your table name
                        ->get()
                        ->result_array();
    }
}
