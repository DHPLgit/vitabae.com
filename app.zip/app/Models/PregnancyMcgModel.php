<?php

namespace App\Models;

use CodeIgniter\Model;

class PregnancyMcgModel extends Model
{
    protected $table = 'pregnancy_mcg';
    protected $primaryKey = 'id';
    protected $allowedFields = ['Nutrients', 'Source_Of_Goal', 'Age', '1st_Trimester','2nd_Trimester','3rd_Trimester','Nutrient_id'];
}
