<?php

namespace App\Models;

use CodeIgniter\Model;

class MaleMcgModel extends Model
{
    protected $table = 'male_mcg';
    protected $primaryKey = 'id';
    protected $allowedFields = ['Nutrients', 'Source_Of_Goal','2to3','4to8 ','9to13','14to18','19to30','31to50','50to70 ','70plus','Nutrient_id'];
}
