<?php

namespace App\Models;

use CodeIgniter\Model;

class LactatingMcgModel extends Model
{
    protected $table = 'lactating_mcg';
    protected $primaryKey = 'id';
    protected $allowedFields = ['Nutrients', 'Source_Of_Goal', 'Age', 'oto6_months','7to12_months','Nutrient_id'];
}
