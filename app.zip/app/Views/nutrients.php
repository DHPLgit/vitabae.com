<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>

<section class="nutrients"></section>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100..900;1,100..900&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap');

    @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');

    .nutriention-input .input-field label {
        font-weight: bold;
        margin-right: 10px;
        color: #555;
        color: #000;
        font-family: "Raleway", sans-serif;
        font-size: 16px;
        font-style: normal;
        font-weight: 600;
        margin: 10px 0px 20px;
        line-height: normal;
    }

    .nutriention-input .input-field span {
        color: #000;
        font-family: "Montserrat", sans-serif;
        font-size: 16px;
        font-style: normal;
        font-weight: 400;
        line-height: normal;
    }

    .nutriention-input button {
        padding: 11px 40px;
        border-radius: 20px;
        border: 1px solid #ccc;
        margin-right: 10px;
        background-color: #f0f0f0;
        cursor: pointer;
    }

    .nutriention-input button.active {
        /* background-color: #4CAF50; */
        color: white;
    }

    .nutriention-input input[type="text"] {
        padding: 5px;
        border-radius: 13px;
        border: 1px solid #E9D2BB;
        background: rgba(217, 185, 155, 0.00);
        width: 100px;
    }

    .nutriention-input .input-field input[type=radio] {
        appearance: none;
        padding: 8px;
        margin: 0px 5px;
        background-color: rgba(231, 231, 231, 1);
        border-radius: 50%;
    }

    .nutriention-input .input-field input[type=radio]:checked {
        background-color: rgba(129, 96, 73, 1);
        padding: 5px;
        border: 3px solid rgba(233, 210, 187, 1);
    }

    #nutrients-table table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        background-color: #fff;
    }

    #nutrients-table tbody {
        border-bottom: 1px solid #767676;
    }

    #nutrients-table td {
        border-right: 1px solid #767676;
        padding: 10px;
        text-align: center;
        color: #000;
        font-family: "Montserrat", sans-serif;
        font-size: 16px;
        font-style: normal;
        font-weight: 400;
        line-height: 30px;
    }

    #nutrients-table th {
        border: 1px solid #767676;
        padding: 10px;
        text-align: center;
    }

    #nutrients-table thead tr th {
        background-color: #ffffff;
    }

    /* td:nth-child(even) {
            background-color: #f2f2f2;
        } */

    #nutrients-table {
        display: none;
        margin: auto;
        width: 100%;
    }

    .nutriention-input {
        text-align: left;
        padding-top: 60px;
    }

    .hidden {
        display: none;
    }

    .nutrietion-content h1 {
        color: #A0816C;
        font-family: "Raleway", sans-serif;
        /* font-size: 32px; */
        font-style: normal;
        font-weight: 600;
        text-align: left;
        margin-bottom: 30px;
    }

    .nutrietion-content p {
        color: #000;
        font-family: "Montserrat", sans-serif;
        font-size: 16px;
        font-style: normal;
        font-weight: 400;
        text-align: left;
        line-height: 30px;
        /* 187.5% */
    }

    .nutrietion-content h2 {
        color: #A0816C;
        font-family: "Montserrat", sans-serif;
        font-size: 28px;
        font-style: normal;
        font-weight: 500;
        text-align: left;
        line-height: 40px;
        /* 187.5% */
    }

    .nutrietion-content h3 {
        color: #000;
        font-family: "Montserrat", sans-serif;
        font-size: 20px;
        font-style: normal;
        font-weight: 500;
        text-align: left;
        line-height: 40px;
        /* 187.5% */
    }

    .nutriention-input .input-field {
        padding-right: 10px;
        text-align: left;
    }

    .nutriention-input-field {
        display: flex;
        justify-content: space-between;
    }

    .Nutrient-radio {
        text-align: left;
        padding: 50px 0px;
        display: flex;
        justify-content: space-between;
    }

    .Nutrient-radio span {
        color: #000;
        font-family: "Raleway", sans-serif;
        font-size: 16px;
        font-style: normal;
        font-weight: 600;
        line-height: normal;
    }

    .Nutrient-radio input {
        accent-color: #858585;
        appearance: none;
        padding: 14px;
        margin: -8px 5px;
        background-color: rgba(231, 231, 231, 1);
        border-radius: 30%;
    }

    .Nutrient-radio input[type=radio]:checked {
        background-color: rgba(233, 210, 187, 1);
        background: url(images/icons/chk-box.png) no-repeat center;
    }

    .submit-nut {
        border-radius: 40px;
        padding: 10px 40px;
        background: linear-gradient(90deg, #D9B99B 34.9%, #EED9C4 100%);
    }

    .submit-nut {
        color: #343045;
        font-family: "Montserrat", sans-serif;
        font-size: 16px;
        font-style: normal;
        font-weight: 600;
        line-height: normal;
    }

    #nutrients-table .default {
        background-color: rgba(237, 208, 181, 0.6);
        /* width: 250px; */
    }

    #nutrients-table thead tr th {
        color: #000;
        width: 250px;
        text-align: center;
        font-family: "Inter", sans-serif;
        font-size: 20px;
        font-style: normal;
        font-weight: 500;
        line-height: normal;
    }

    .highlight {
        background-color: rgba(237, 208, 181, 0.6);
        /* Light grey background color */
        border-left: 1px solid #767676;
    }

    .nut-table {
        padding: 70px 0px;
    }

    .nut-table h4 {
        text-align: left;
        color: #000;
        font-family: "Raleway", sans-serif;
        font-size: 18px;
        font-style: normal;
        font-weight: 400;
        line-height: 40px;
    }

    .nut-table h4 b {
        text-align: left;
        color: #000;
        font-family: "Raleway", sans-serif;
        font-size: 20px;
        font-style: normal;
        font-weight: 600;
        line-height: 30px;
    }

    /* #nut-table {
        display: none;
    } */

    #stage {
        padding: 5px;
        border-radius: 13px;
        border: 1px solid #E9D2BB;
        background: rgba(217, 185, 155, 0.00);

    }

    #stage option {
        background: #e2d0ba;
        color: #fff;
    }

    #female_age_drpdwn {
        padding: 5px;
        border-radius: 13px;
        border: 1px solid #E9D2BB;
        background: rgba(217, 185, 155, 0.00);
        width: 150px;
    }

    #female_age_drpdwn option {
        background: #e2d0ba;
        color: #fff;
    }

    #female_age_drpdwn option:root {
        background: #e2d0ba;
        color: #fff;
    }
</style>
</head>

<body>
    <section class="nutriention">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="nutrietion-content"><br /><br /><br />
                        <h1>Personalized Nutrition Guide for a Healthy Pregnancy</h1>
                        <p>
                            Welcome to Vitabae! Our goal is to offer superior wellness advice and products. Our
                            Personalized Nutrient Requirements page assists you in identifying the supplements and
                            vitamins that are best for you based on your individual needs.</p>

                        <h2>Here's how it works:</h2>

                        <h3>1. Input Your Information: </h3>
                        <p>Enter your age and gender, and, if applicable, select your current stage of pregnancy from
                            the options provided.</p>

                        <h3>2. Receive Personalized Recommendations:</h3>
                        <p>Our system, backed by scientific research to support your unique needs, will generate a
                            customized list of essential nutrients for your specific health requirements based on the
                            information you provide.</p>

                        <h3>3. Understand Your Nutrient Needs:</h3>
                        <p>Each daily nutrition recommendation in your guide comes with science-based advice on dosages.
                            For more detailed information about our nutrient sources, sustainability, and how nutrients
                            interact with others for optimal absorption, check out the Vitabae blog page.</p>
                        </p>
                        <p>The Vitabae Personal Nutrition Guide uses different formulas based on the user's age, and
                            additional adjustment factors may be applied based on other user-entered information.</p>
                        <p>Sources used include <a href="https://www.ncbi.nlm.nih.gov/books/NBK234926/">Recommended
                                Dietary Allowance (RDA)</a>, <a
                                href="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5347101/#:~:text=The%20Acceptable%20Macronutrient%20Distribution%20Range%20%28AMDR%29%20%2810%E2%80%9335,than%20that%20of%20the%20RDA%2E">Acceptable
                                Macronutrient Distribution Range (AMDR)</a>, <a
                                href="https://health.gov/our-work/nutrition-physical-activity/dietary-guidelines/dietary-reference-intakes#:~:text=The%20values%20for%20reducing%20risk,disease%20risk%20reduction%20intake%20%28CDRR%29">Chronic
                                Disease Risk Reduction Intake (CDRR)</a>, and <a
                                hfre="https://www.ncbi.nlm.nih.gov/books/NBK222886/">Adequate Intake (AI)</a>.
                            Calculations for people who are pregnant or lactating vary based on age and other factors.
                        </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <!-- <h1>Nutrients by Age</h1> -->

                    <div class="nutriention-input">
                        <div class="nutriention-input-field">
                            <div class="input-field">
                                <label for="age-input">Age</label></br>
                                <input type="text" id="age-input" placeholder="">
                                <select id="female_age_drpdwn" style="display: none;">
                                    <option value="14-18">14-18</option>
                                    <option value="19-30">19-30</option>
                                    <option value="31-50">31-50</option>
                                </select>
                            </div>
                            <div class="input-field">
                                <label>Gender</label></br>
                                <input type="radio" id="male" name="sex" value="Male"><span>Male</span></button>
                                <input type="radio" id="female" name="sex" value="Female"><span>Female</span>
                            </div>
                        </div>
                        <div class="input-field" id="dropdown" style="display: none;">
                            <label>Select stage</label></br>
                            <select id="stage">
                                <option value="Female">Not Pregnant</option>
                                <option value="1st_Trimester">1st Trimester</option>
                                <option value="2nd_Trimester">2nd Trimester</option>
                                <option value="3rd_Trimester">3rd Trimester</option>
                                <option value="0-6 months">Lactating 0-6 months</option>
                                <option value="7-12 months">Lactating 7-12 months</option>
                            </select>
                        </div>
                        <div class="Nutrient-radio">
                            <!-- <label>Nutrients:</label></br> -->
                            <div>
                                <input type="radio" name="nut" value="1"><span>Vitamins</span></button>
                            </div>
                            <div><input type="radio" name="nut" value="2"><span>Minerals</span></button>
                            </div>
                            <div><input type="radio" name="nut" value="3"><span>Both</span></button>
                            </div>
                            <br>
                            <!-- Add more buttons as needed -->
                        </div>

                        <button class="submit-nut" id="submit-nut">Submit</button>
                        <p id="error" style="display: none;color: red;"> </p>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="nut-table" id="nut-table">
        <div class="container" id="nutrients-table" style="display: none;">
            <h4>Vitamins Recommended Daily Intake <b>(*RDA - Recommended Daily Allowances)</b></h4>
            <table class="nut-table" border="1">
                <thead>
                    <tr>
                        <th class="default">Nutrients</th>
                        <th class="default">Source of Goal</th>
                        <th class="age-group ">2-3 (M/F)</th>
                        <th class="age-group ">4-8 Female</th>
                        <th class="age-group ">4-8 Male</th>
                        <th class="age-group ">9-13 Female</th>
                        <th class="age-group ">9-13 Male</th>
                        <th class="age-group ">14-18 Female</th>
                        <th class="age-group ">14-18 Male</th>
                        <th class="age-group ">19-30 Female</th>
                        <th class="age-group ">19-30 Male</th>
                        <th class="age-group ">31-50 Female</th>
                        <th class="age-group ">31-50 Male</th>
                        <th class="age-group ">50-70 Female</th>
                        <th class="age-group ">50-70 Male</th>
                        <th class="age-group ">&gt;70 Female</th>
                        <th class="age-group ">&gt;70 Male</th>
                        <th class="age-group">14-18/1st Trimester</th>
                        <th class="age-group ">14-18/2nd Trimester</th>
                        <th class="age-group ">14-18/3rd Trimester</th>
                        <th class="age-group ">19-30/1st Trimester</th>
                        <th class="age-group ">19-30/2nd Trimester</th>
                        <th class="age-group ">19-30/3rd Trimester</th>
                        <th class="age-group ">31-50/1st Trimester</th>
                        <th class="age-group ">31-50/2nd Trimester</th>
                        <th class="age-group ">31-50/3rd Trimester</th>
                        <th class="age-group ">14-18/0-6 months</th>
                        <th class="age-group ">14-18/7-12 months</th>
                        <th class="age-group ">19-30/0-6 months</th>
                        <th class="age-group ">19-30/7-12 months</th>
                        <th class="age-group ">31-50/0-6 months</th>
                        <th class="age-group ">31-50/7-12 months</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Rows will go here -->
                </tbody>
            </table>

        </div>
    </section>
    <!-- Nutrients Table -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        th.age-group {
            display: none;
            /* Hide all age group headers initially */
        }
    </style>
    <script>
        $(document).ready(function () {
            // When "Female" is selected, show the stage dropdown and age group dropdown
            $("#female").on("click", function () {
                $("#dropdown").show();  // Show the stage dropdown
                $("#female_age_drpdwn").hide(); // Initially hide the female age dropdown
                $("#age-input").show(); // Show the default input field
            });

            // When "Male" is selected, hide the stage dropdown
            $("#male").on("click", function () {
                $("#dropdown").hide();  // Hide the stage dropdown
                $("#age-input").show(); // Show the regular age input field
                $("#female_age_drpdwn").hide(); // Hide the female age dropdown
                $("#stage").val('Male');  // Set the stage value to "Male" when Male is selected
            });

            // When the stage dropdown is changed
            $("#stage").on("change", function () {
                let stage = $(this).val();
                if (stage === "Female") {
                    // "Not Pregnant" is selected
                    $("#age-input").show();  // Show the regular age input field
                    $("#female_age_drpdwn").hide();  // Hide the female-specific age dropdown
                } else {
                    // For pregnancy stages, show the female age dropdown
                    $("#age-input").hide(); // Hide the regular age input field
                    $("#female_age_drpdwn").show();  // Show the female age dropdown
                }
            });

            $("#submit-nut").on("click", function () {
                let age = $("#age-input").val();
                let sex = $("input[name='sex']:checked").val();
                let stage = "";

                // If Female is selected, get the stage value and age range
                if (sex === "Female") {
                    stage = $("#stage").val();  // Get the selected stage value
                    if (stage === "Female") {
                        // If Not Pregnant, use the regular age input field
                        age = $("#age-input").val();  // Use the regular age field
                    } else if ($("#female_age_drpdwn").is(":visible")) {
                        age = $("#female_age_drpdwn").val();  // Use the selected age range for female
                    }
                } else if (sex === "Male") {
                    stage = "Male";  // When Male is selected, set stage to "Male"
                }

                let nutrient = $("input[name='nut']:checked").val();

                // Validation check for required fields
                if (!age || !sex || !nutrient || (sex === "Female" && !stage)) {
                    $("#error").text("Please fill all fields, including the stage if Female.").show();
                    return;
                }

                const requestData = {
                    age: age,
                    nutrient_id: nutrient,
                    stage: stage || ""  // Send an empty string if no stage is selected
                };

                //console.log("Generated URL: https://www.vitabae.com/nutritionData");
                console.log("Payload:", requestData);
                $.ajax({
                    url: '/nutritionData',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(requestData),
                    dataType: 'json',
                    success: function (response) {
                        console.log('Full Response:', response);  // Log the full response

                        if (response && response.length > 0) {
                            appendToTable(response);  // Directly use response if it contains the expected data
                            $('#nutrients-table').show();
                        } else {
                            console.error('No data found or incorrect structure:', response);
                            $("#error").text('Failed to retrieve data.').show();
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('Error:', error);
                        console.error('Response Text:', xhr.responseText);
                        $("#error").text('Failed to submit data. Please try again later.').show();
                    }
                });
            });


            // Function to append the received data to the table
            function appendToTable(data) {
                console.log('Data inside appendToTable:', data); // Log the data received

                const tableBody = $("#nutrients-table tbody");
                tableBody.empty(); // Clear old rows

                if (data.length === 0) {
                    alert("No data available for the selected inputs.");
                    $("#nutrients-table").hide();
                    return;
                }

                console.log('Before appending rows:', tableBody.html());

                data.forEach(item => {
                    const value = item.Value || "No data"; // If Value is empty, show "No data"
                    const row = `
                    <tr>
                        <td class="highlight">${item.x}</td>
                        <td class="highlight">${item["Source of Goal"]}</td>
                        <td>${value}</td>
                    </tr>`;
                    tableBody.append(row);
                });

                $("#nutrients-table").show(); // Ensure the table is visible

                console.log('After appending rows:', tableBody.html());
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
            // Change the title based on some condition or event
            document.getElementById("pageTitle").innerText = "Nutrients";
        </script>
    <script>

    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const ageInput = document.getElementById("age-input");
            const genderInputs = document.querySelectorAll("input[name='sex']");
            const stageDropdown = document.getElementById("stage");
            const submitButton = document.getElementById("submit-nut");
            const errorElement = document.getElementById("error");
            const headers = document.querySelectorAll("th.age-group");
            const femaleAgeDropdown = document.getElementById("female_age_drpdwn");

            // Function to reset all headers (hide them)
            function resetHeaders() {
                headers.forEach(header => {
                    header.style.display = "none";
                });
            }

            // Function to display the relevant header based on gender, age, and stage
            function displayRelevantHeader() {
                const age = parseInt(ageInput.value, 10);
                const gender = document.querySelector("input[name='sex']:checked")?.value;
                const stage = stageDropdown?.value;
                const selectedAgeGroup = femaleAgeDropdown?.value;

                // Clear previous error
                errorElement.style.display = "none";
                errorElement.textContent = "";

                resetHeaders();

                let targetHeaderText = "";

                // Validation and logic for Male
                if (gender === "Male") {
                    if (!age) {
                        errorElement.style.display = "block";
                        errorElement.textContent = "Please enter age.";
                        return;
                    }

                    if (age >= 2 && age <= 3) targetHeaderText = "2-3 (M/F)";
                    else if (age >= 4 && age <= 8) targetHeaderText = "4-8 Male";
                    else if (age >= 9 && age <= 13) targetHeaderText = "9-13 Male";
                    else if (age >= 14 && age <= 18) targetHeaderText = "14-18 Male";
                    else if (age >= 19 && age <= 30) targetHeaderText = "19-30 Male";
                    else if (age >= 31 && age <= 50) targetHeaderText = "31-50 Male";
                    else if (age >= 50 && age <= 70) targetHeaderText = "50-70 Male";
                    else if (age > 70) targetHeaderText = ">70 Male";
                }

                // Validation and logic for Female
                if (gender === "Female") {
                    if (!stage) {
                        errorElement.style.display = "block";
                        errorElement.textContent = "Please select a stage.";
                        return;
                    }

                    if (stage === "Female") {
                        // If "Not Pregnant" is selected, validate age input
                        if (!age) {
                            errorElement.style.display = "block";
                            errorElement.textContent = "Please enter age.";
                            return;
                        }

                        targetHeaderText = getFemaleHeaderByAge(age);
                    } else {
                        // For other stages, ensure age group is selected
                        if (!selectedAgeGroup) {
                            errorElement.style.display = "block";
                            errorElement.textContent = "Please select an age group.";
                            return;
                        }

                        // Determine header for the selected age group and stage
                        if (selectedAgeGroup === "14-18") {
                            if (stage === "1st_Trimester") targetHeaderText = "14-18/1st Trimester";
                            else if (stage === "2nd_Trimester") targetHeaderText = "14-18/2nd Trimester";
                            else if (stage === "3rd_Trimester") targetHeaderText = "14-18/3rd Trimester";
                            else if (stage === "0-6 months") targetHeaderText = "14-18/0-6 months";
                            else if (stage === "7-12 months") targetHeaderText = "14-18/7-12 months";
                        } else if (selectedAgeGroup === "19-30") {
                            if (stage === "1st_Trimester") targetHeaderText = "19-30/1st Trimester";
                            else if (stage === "2nd_Trimester") targetHeaderText = "19-30/2nd Trimester";
                            else if (stage === "3rd_Trimester") targetHeaderText = "19-30/3rd Trimester";
                            else if (stage === "0-6 months") targetHeaderText = "19-30/0-6 months";
                            else if (stage === "7-12 months") targetHeaderText = "19-30/7-12 months";
                        } else if (selectedAgeGroup === "31-50") {
                            if (stage === "1st_Trimester") targetHeaderText = "31-50/1st Trimester";
                            else if (stage === "2nd_Trimester") targetHeaderText = "31-50/2nd Trimester";
                            else if (stage === "3rd_Trimester") targetHeaderText = "31-50/3rd Trimester";
                            else if (stage === "0-6 months") targetHeaderText = "31-50/0-6 months";
                            else if (stage === "7-12 months") targetHeaderText = "31-50/7-12 months";
                        }
                    }
                }

                // Display the header matching the target header text
                headers.forEach(header => {
                    if (header.textContent.trim() === targetHeaderText) {
                        header.style.display = "table-cell";
                    }
                });

                // Show error if no valid header is found
                if (!targetHeaderText) {
                    errorElement.style.display = "block";
                    errorElement.textContent = "No matching header found.";
                }
            }

            // Function to get the correct header for female based on age
            function getFemaleHeaderByAge(age) {
                if (age >= 2 && age <= 3) return "2-3 (M/F)";
                else if (age >= 4 && age <= 8) return "4-8 Female";
                else if (age >= 9 && age <= 13) return "9-13 Female";
                else if (age >= 14 && age <= 18) return "14-18 Female";
                else if (age >= 19 && age <= 30) return "19-30 Female";
                else if (age >= 31 && age <= 50) return "31-50 Female";
                else if (age >= 50 && age <= 70) return "50-70 Female";
                else if (age > 70) return ">70 Female";
                return "";
            }
            
            // Event listener for the submit button to trigger the header display
            submitButton.addEventListener("click", function (event) {
                document.getElementById("nut-table").scrollIntoView({ behavior: "smooth" });
                event.preventDefault(); // Prevent default form submission
                displayRelevantHeader();
                

            });
        });

        document.addEventListener('DOMContentLoaded', function () {
            // Change the title based on some condition or event
            document.getElementById('pageTitle').innerText = 'Personalized Nutrition Guide | Science-Based Daily Recommendations';

            // Change the meta tags based on some condition or event
            document.getElementById('metatags').setAttribute('content', "Support your pregnancy with Vitabae's personalized nutrition guide. Get science-backed daily nutrient recommendations tailored to each stage of pregnancy for optimal health and wellness.");
        });
    </script>

    <?php echo script_tag('js/jquery.min.js'); ?>
    <?= $this->endSection() ?>