<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>
<section class="contact-us-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <h1>Contact us</h1>
                <div class="contact-content">
                    <p>
                        Feel free to reach out to us at any time.<br />We value your feedback and inquiries.
                    </p>
                    <button (click)="loadTypeformScript()" class="contact-message" data-bs-toggle="modal"
                        data-bs-target="#send-mess">Send
                        Message</button>
                    <!-- Modal -->
                    <div class="modal fade" id="send-mess" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div data-tf-live="01HKR5M3EDQN8045N0T90VSNP9"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="contact-content-2">
                    <!-- <p class=" d-none d-lg-block">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, Lorem ipsum dolor sit amet, consectetur
                        adipiscing elit, sed
                    </p> -->
                    <a href="#" class="contact-email  d-none d-lg-block">admin@vitabae.com</a>
                    <div class="contact-details">
                        <!-- <div class="details">
                            <img src="<?php echo base_url(); ?>images/icons/Ringing-Phone.png" class="img-fluid" />
                            <p>+987654321</p>
                        </div> -->
                        <div class="details">
                            <img src="<?php echo base_url(); ?>images/icons/Shop-Location.png" class="img-fluid" />
                            <p>Los Angeles</p>
                        </div>

                        <div class="details  d-none d-lg-block">
                            <a href="https://www.instagram.com/thevitabae/"><img
                                    src="<?php echo base_url(); ?>images/icons/Instagram-Circle.png"
                                    class="img-fluid" /></a>
                            <a href=" https://www.facebook.com/people/The-Vitabae/100068215744497/"><img
                                    src="<?php echo base_url(); ?>images/icons/Facebook-2.png" class="img-fluid" /></a>
                            <!--- <a href="#"><img src="<?php echo base_url(); ?>images/icons/YouTube-2.png" class="img-fluid" /></a>-->
                        </div>

                    </div>
                    <div class="contact-content-2 d-lg-none">
                        <!-- <p>
                Feel free to reach out to us at any time.<br/>We value your feedback and inquiries.
            </p> -->
                        <a href="#" class="contact-email">admin@vitabae.com</a>
                        <div class="contact-details">
                            <div class="details">
                                <a href="#"><img src="<?php echo base_url(); ?>images/icons/Instagram-Circle.png"
                                        class="img-fluid" /></a>
                                <a href="#"><img src="<?php echo base_url(); ?>images/icons/Facebook-2.png"
                                        class="img-fluid" /></a>
                                <a href="#"><img src="<?php echo base_url(); ?>images/icons/YouTube-2.png"
                                        class="img-fluid" /></a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="container">

    </div>
</section>
<!-- <app-form></app-form> -->
<!-- <section class="contact-form">
    <div class="container">
        <div class="form">
            <form>
                <h2 class=" d-none d-lg-block">Send Us Your Feedback-<span>We Value your opinion</span></h2>
                <h2 class="d-lg-none">Send Us Your Feedback<br/><span>We Value your opinion</span></h2>
                <div class="row">
                    <div class=" col-md-6">
                        <div class="form-content">
                            <input type="text" placeholder="Name" class="name" />
                        </div>
                        <div class="form-content">
                            <input type="email" placeholder="Email" class="email" />
                        </div>
                    </div>
                    <div class=" col-md-6">
                        <div class="form-content">
                            <input type="tel" placeholder="Phone Number" class="phone" />
                        </div>
                        <div class="form-content">
                            <input type="text" placeholder="Subject" class="subject" />
                        </div>
                    </div>
                    <div class="form-content">
                        <input type="text" placeholder="Message" class="message" />
                    </div>
                    <div class="submit-btn-contact">
                        <button class="btn contact-message-btn">Send Message</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section> -->






<section class="accordion-contact">
    <div class="container">
        <div class="accordion-contact-detail">
            <h2>FAQ</h2>
            <div class="accordion accordion-flush" id="accordionExample">
                <div class="row">
                    <div class="col-md-6">
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    How do I change my email?
                                </button>
                            </h3>
                            <div id="collapseOne" class="accordion-collapse collapse show"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    You can log in to your account and change it from your Profile.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    What should I do if my payment is declined?
                                </button>
                            </h3>
                            <div id="collapseTwo" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    If your payment is declined, please contact our customer service. You may also need
                                    to contact your bank.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    What is your cancellation policy?
                                </button>
                            </h3>
                            <div id="collapseThree" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    You can now cancel an order before it shipping. Once an order has shipped, please
                                    contact our customer service team.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    How do I customize my prenatal?
                                </button>
                            </h3>
                            <div id="collapseFour" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    You can customize your prenatal by going to any product page and clicking the Click
                                    Here Button in the customization section.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    Are all your raw materials from USDA certified organic farms?
                                </button>
                            </h3>
                            <div id="collapseFive" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Yes, all our raw ingredients are sourced exclusively from farms that have been
                                    certified by the USDA for Organic practices. This commitment ensures our products
                                    are made from only the highest quality, organic materials.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                    I can't log into my account. What should I do?
                                </button>
                            </h3>
                            <div id="collapseSix" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Yes, we own the factory where the supplements are manufactured. This allows us full
                                    control over the production process to ensure the highest quality standards.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                    How do I update my shipping address?
                                </button>
                            </h3>
                            <div id="collapseSeven" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    You can update your shipping address by logging into your account, going to the
                                    "Addresses" section, and selecting "Edit" under your current shipping address. You
                                    may also add a new address if needed.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                                    What should I do if my package is damaged or missing?
                                </button>
                            </h3>
                            <div id="collapseEight" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    If your package arrives damaged or is missing, please contact our customer support
                                    team immediately. Provide them with your order number and, if possible, photos of
                                    the damaged package. We will investigate the issue and offer a suitable solution,
                                    such as a replacement or refund, to resolve the matter promptly.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                                    How do I check order status?
                                </button>
                            </h3>
                            <div id="collapseNine" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Please check the “My Orders” section, in your account.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                                    How do I request a refund on an order?
                                </button>
                            </h3>
                            <div id="collapseTen" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    For any order that has already been deliverd, please reach out to our customer
                                    service team, to proceed with a refund. Please also read our return policy.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseEleven" aria-expanded="false"
                                    aria-controls="collapseEleven">
                                    How do I apply a coupon to my order?
                                </button>
                            </h3>
                            <div id="collapseEleven" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    You can apply a coupon on cart page before you place an order. If you are having any
                                    issue using a valid coupon, please contact our customer service team for assiatance.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwelve" aria-expanded="false"
                                    aria-controls="collapseTwelve">
                                    Does Vitabae own the factory where the supplements are manufactured?
                                </button>
                            </h3>
                            <div id="collapseTwelve" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Yes, we own the factory where the supplements are manufactured. This allows us full
                                    control over the production process to ensure the highest quality standards.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseThirteen" aria-expanded="false"
                                    aria-controls="collapseThirteen">
                                    How does your company ensure the safety and efficacy of its supplements?
                                </button>
                            </h3>
                            <div id="collapseThirteen" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    We conduct rigorous in-house testing on all our supplements to ensure their nutrient
                                    safety and efficacy.
                                    Our dedicated team of experts utilizes state-of-the-art technology to verify quality
                                    at every stage of production, guaranteeing our customers receive only the safest and
                                    most effective products.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFourteen" aria-expanded="false"
                                    aria-controls="collapseFourteen">
                                    How do I update my contact information?
                                </button>
                            </h3>
                            <div id="collapseFourteen" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    To update your contact information, log into your account, navigate to the "My
                                    Account" section, and select "Edit Profile" or "Contact Information." From there,
                                    you can update your email, phone number, and other personal details.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFifteen" aria-expanded="false"
                                    aria-controls="collapseFifteen">
                                    How do I update my billing details?
                                </button>
                            </h3>
                            <div id="collapseFifteen" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">

                                    To update your billing details, log into your account and access the "Payment
                                    Methods" section. Here, you can edit your existing billing information or add a new
                                    payment method for future purchases.

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<section class="accordion-contact">
    <div class="container">
        <div class="accordion-contact-detail">
            <h2>Subscribe & Save FAQ</h2>
            <div class="accordion accordion-flush" id="accordionExample2">
                <div class="row">
                    <div class="col-md-6">
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseSixteen" aria-expanded="true" aria-controls="collapseSixteen">
                                    What is the Subscribe & Save Program?
                                </button>
                            </h3>
                            <div id="collapseSixteen" class="accordion-collapse collapse show"
                                data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    The Subscribe & Save Program allows customers to receive their favorite products
                                    automatically on a regular schedule, ensuring they never run out. Subscribers enjoy
                                    a discount on every order and free shipping, making it a convenient and
                                    cost-effective option.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseSeventeen" aria-expanded="false" aria-controls="collapseSeventeen">
                                    How do I subscribe to a product?
                                </button>
                            </h3>
                            <div id="collapseSeventeen" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    To subscribe, simply choose the Subscribe & Save option on the product page before
                                    adding it to your cart. Select your preferred delivery frequency, and proceed to
                                    checkout. Your subscription will start immediately after your first order is
                                    processed.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseEighteen" aria-expanded="false" aria-controls="collapseEighteen">
                                    Can I choose the frequency of my deliveries?
                                </button>
                            </h3>
                            <div id="collapseEighteen" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    Yes, you can select your preferred delivery frequency from the options available on
                                    the product page. Common frequencies include monthly, bi-monthly, and quarterly. You
                                    can adjust this frequency at any time through your account settings.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseNinteen" aria-expanded="false" aria-controls="collapseNinteen">
                                    How do I manage my subscription?
                                </button>
                            </h3>
                            <div id="collapseNinteen" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    You can manage your subscription through your account dashboard. Here, you can
                                    change the delivery frequency, pause or cancel your subscription, update your
                                    address or payment information, and add or remove products.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwenty" aria-expanded="false" aria-controls="collapseTwenty">
                                    Will I be notified before my subscription order is shipped?
                                </button>
                            </h3>
                            <div id="collapseTwenty" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    Yes, we send a reminder email a few days before your next order is scheduled to
                                    ship. This email will confirm the products, quantities, delivery date, and price.
                                    You'll have the opportunity to make any last-minute adjustments.
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwentyone" aria-expanded="false" aria-controls="collapseTwentyone">
                                    Can I return a subscription order if I'm not satisfied?
                                </button>
                            </h3>
                            <div id="collapseTwentyone" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    Yes, our satisfaction guarantee applies to all orders, including subscription
                                    orders. If you're not satisfied with your purchase, you can return it within a
                                    specified period for a refund or exchange, according to our return policy.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwentytwo" aria-expanded="false" aria-controls="collapseTwentytwo">
                                    How does billing work for Subscribe & Save orders?
                                </button>
                            </h3>
                            <div id="collapseTwentytwo" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    Your payment method on file will be charged automatically on the date your order is
                                    scheduled to ship. You'll receive an email confirmation once the payment has been
                                    processed and your order is on its way.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwentythree" aria-expanded="false" aria-controls="collapseTwentythree">
                                    How do I cancel my subscription?
                                </button>
                            </h3>
                            <div id="collapseTwentythree" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    You can cancel your subscription at any time through your account dashboard. There
                                    are no cancellation fees, but we recommend canceling at least 24 hours before your
                                    next scheduled shipment to avoid being charged for the next order.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwentyfour" aria-expanded="false" aria-controls="collapseTwentyfour">
                                    What are the benefits of the Subscribe & Save Program?
                                </button>
                            </h3>
                            <div id="collapseTwentyfour" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    Subscribers benefit from a discount on every subscription order, free shipping, and
                                    the convenience of automatic deliveries. This ensures you always have your essential
                                    products without having to remember to reorder them.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwentyfive" aria-expanded="false" aria-controls="collapseTwentyfive">
                                    Is there a minimum commitment period for subscriptions?
                                </button>
                            </h3>
                            <div id="collapseTwentyfive" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample2">
                                <div class="accordion-body">
                                    No, there is no minimum commitment period. You can cancel your subscription anytime
                                    without penalty.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Change the title based on some condition or event
        document.getElementById('pageTitle').innerText = 'Reach Out to Vitabae | For Support & Information';
        
        // Change the meta tags based on some condition or event
        document.getElementById('metatags').setAttribute('content', 'Contact Vitabae to provide feedback or ask questions. We\'re here to support you with personalized answers and ensure your pregnancy experience is well-informed.');
    });
</script>
<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>