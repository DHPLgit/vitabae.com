<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>

<section class="about">
    <!-- desktop -->
    <div id="carouselExampleCaptions" class="carousel slide d-none d-lg-block">
        <!-- <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div> -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo base_url(); ?>images/banner/about-ban.png" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                <div class="row">
                <div class="col-md-4">
                </div>
                <div class="col-md-8 ">
                    <h5>OUR STORY</h5>
                    <!-- <h5><span> Pregnancy</span></h5> -->
                    <p>At Vitabae, our vision is to revolutionize prenatal care by addressing challenges that mainstream
                        products have overlooked. We are committed to creating a prenatal supplement that not only
                        caters to your unique needs but also enhances your experience by minimizing unpleasant odors and
                        tastes. Transparency is at the core of our philosophy. From the meticulous sourcing of our
                        ingredients to the operations in our privately-owned facility, we invite you to join us on every
                        step of this journey. With Vitabae, you're not just choosing a product; you're embracing an
                        experience of informed choice and clarity. Dive into our research, witness our production
                        process, and discover the distinct qualities that make Vitabae's prenatal supplement a leader in
                        its class. Welcome to a world of openness and innovation with Vitabae. </p>
                        </div>
                </div>
                </div>
            </div>
            <!-- <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Second slide label</h5>
              <p>Some representative placeholder content for the second slide.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Third slide label</h5>
              <p>Some representative placeholder content for the third slide.</p>
            </div>
          </div> -->
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev">
            <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next">
            <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <!-- mobile -->
    <div id="carouselExampleCaptions" class="carousel slide d-flex d-lg-none">
        <!-- <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div> -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo base_url(); ?>images/banner/abt-sm-banner.png" class="" alt="...">
            </div>
            <!-- <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Second slide label</h5>
              <p>Some representative placeholder content for the second slide.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="..." class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Third slide label</h5>
              <p>Some representative placeholder content for the third slide.</p>
            </div>
          </div> -->
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev">
            <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next">
            <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
            <span class="visually-hidden">Next</span>
        </button>
    </div>

</section>
<section class="d-lg-none">
    <div class="container">

        <div class="carousel-content-banner">
            <h5>OUR STORY</h5>
            <!-- <h5><span> Pregnancy</span></h5> -->
            <p>At Vitabae, our vision is to revolutionize prenatal care by addressing challenges that mainstream
                products have overlooked. We are committed to creating a prenatal supplement that not only caters to
                your unique needs but also enhances your experience by minimizing unpleasant odors and tastes.
                Transparency is at the core of our philosophy. From the meticulous sourcing of our ingredients to the
                operations in our privately-owned facility, we invite you to join us on every step of this journey. With
                Vitabae, you're not just choosing a product; you're embracing an experience of informed choice and
                clarity. Dive into our research, witness our production process, and discover the distinct qualities
                that make Vitabae's prenatal supplement a leader in its class. Welcome to a world of openness and
                innovation with Vitabae. </p>
        </div>
    </div>
</section>
<section class="aboutwhoweare mt-2">
    <div class="container-fluid">
        <!-- desktop view -->
        <div class="d-none d-lg-block">
            <div class="row ">
                <div class="col-md-8  col-sm-12">
                    <div class="head">
                        <h3>Who We Are</h3>
                        <!-- <div class="d-flex justify-content-start">
                            <p>Nam libero tempore</p>
                            <img src="<?php echo base_url(); ?>images/icons/Component-1.png" />
                        </div> -->
                        <div class="head-2">
                            <p>
                                Welcome to our innovative journey, where a team of committed doctors and pioneering
                                entrepreneurs unite to redefine prenatal care. At the heart of our mission lies a
                                groundbreaking approach to prenatal supplements, meticulously crafted based on
                                scientific principles and tailored to meet the unique needs of each individual. We
                                understand that pregnancy is a journey of constant change, and our bespoke product is
                                designed to evolve with the dynamic needs of a woman’s body during this special time.
                                Our dedication goes beyond the ordinary, aiming to deliver a personalized health
                                experience that nurtures both the mother and the baby, setting us apart from the
                                conventional, one-size-fits-all prenatal solutions. Join us in embracing a prenatal care
                                experience that is as unique as you are.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="About-img">
                        <!-- desktop view -->
                        <img src="<?php echo base_url(); ?>images/banner/abt-sec-2.png"
                            class="img-fluid  d-none d-lg-block" />

                    </div>
                </div>
            </div>
        </div>
        <!-- mobile view -->
        <div class="d-flex d-lg-none">
            <div class="head">
                <div class="">
                    <img src="<?php echo base_url(); ?>images/banner/abt-sec-2.png"
                        class="img-fluid  d-flex d-lg-none" />
                </div>
                <h3>Who We Are</h3>
                <!-- <div class="d-flex justify-content-center">
                    <p>Nam libero tempore</p>
                </div> -->

                <div class="head-2">
                    <p>
                        Welcome to our innovative journey, where a team of committed doctors and pioneering
                        entrepreneurs unite to redefine prenatal care. At the heart of our mission lies a
                        groundbreaking approach to prenatal supplements, meticulously crafted based on
                        scientific principles and tailored to meet the unique needs of each individual. We
                        understand that pregnancy is a journey of constant change, and our bespoke product is
                        designed to evolve with the dynamic needs of a woman’s body during this special time.
                        Our dedication goes beyond the ordinary, aiming to deliver a personalized health
                        experience that nurtures both the mother and the baby, setting us apart from the
                        conventional, one-size-fits-all prenatal solutions. Join us in embracing a prenatal care
                        experience that is as unique as you are.
                    </p>
                </div>

            </div>
        </div>
    </div>
</section>
<section class="pay-us mt-5  d-none d-lg-block">
    <div class="container-fluid">
        <div class="content">
            <div class="row">
                <div class="col-md-4 col-sm-12">
                    <div class="d-flex justify-content-center bd-right">
                        <img src="<?php echo base_url(); ?>images/icons/Goal.png" class="img-fluid" />
                        <div class="content-title">
                            <h3>Innovative Health for Every Pregnancy:</h3>
                            <p> "Our mission is to revolutionize prenatal nutrition by offering customized supplements tailored to each unique pregnancy. Vitabae stands for sustainability, education, and the use of pure organic ingredients to support the diverse needs of pregnant women everywhere."</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="d-flex justify-content-center bd-right">
                        <img src="<?php echo base_url(); ?>images/icons/Eye.png" class="img-fluid" />
                        <div class="content-title">
                            <h3>Transforming Prenatal Health:</h3>
                            <p>"Our vision is to transform the landscape of prenatal health, championing the unique needs of every pregnancy. We aspire to be a beacon of innovation, sustainability, and education in the journey towards motherhood."</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="d-flex justify-content-center bd-last">
                        <img src="<?php echo base_url(); ?>images/icons/Diamond-care.png" class="img-fluid" />
                        <div class="content-title">
                            <h3>Values</h3>
                            <p>Scientific Based Research To Solve The Problems Of Today </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="pay-us  d-lg-none">
    <div class="container">
        <div class="content">
            <div class="row">
                <div class="col-md-4 col-sm-12">
                    <div class=" bd-right">
                        <div class="content-title content-title-fl">
                            <div class="f-lft">
                                <img src="<?php echo base_url(); ?>images/icons/Goal.png" class="img-fluid" />
                            </div>
                            <h3>Innovative Health for Every Pregnancy:</h3>
                        </div>
                        <div class="content-title">
                            
                            <p> "Our mission is to revolutionize prenatal nutrition by offering customized supplements tailored to each unique pregnancy. Vitabae stands for sustainability, education, and the use of pure organic ingredients to support the diverse needs of pregnant women everywhere."</p>

                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class=" bd-right">
                        <div class="content-title content-title-fl">
                            <div class="f-lft">
                                <img src="<?php echo base_url(); ?>images/icons/Eye.png" class="img-fluid" />
                            </div>
                            <h3>Transforming Prenatal Health:</h3>
                        </div>
                        <div class="content-title">
                            
                            <p>"Our vision is to transform the landscape of prenatal health, championing the unique needs of every pregnancy. We aspire to be a beacon of innovation, sustainability, and education in the journey towards motherhood."</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="bd-last">
                        <div class="content-title content-title-fl">
                            <div class="f-lft">
                                <img src="<?php echo base_url(); ?>images/icons/Diamond-care.png"
                                    class="img-fluid" />
                            </div>
                            <h3>Values</h3>
                        </div>
                        <div class="content-title">
                            <p>Scientific Based Research To Solve The Problems Of Today </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="About-pre mt-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-5 col-sm-12">
                <div class="About-img">
                    <!-- desktop view -->
                    <img src="<?php echo base_url(); ?>images/icons/pregnant-woman.png" class="img-fluid" />
                </div>
            </div>
            <div class="col-md-7 col-sm-12">
                <div class="head">
                    <h3>Educating You on Our Unique Formulation</h3>
                    <div class="d-flex-head">

                        <img src="<?php echo base_url(); ?>images/icons/Component-3.png"
                            class=" d-none d-lg-block" />
                        <p class="title">Understanding Your Needs: A Tailored Approach</p>
                    </div>
                    <div class="content">
                        <p>Every pregnancy is unique, and so are your nutritional requirements. Our prenatal supplement is not a one-size-fits-all solution. It's a symphony of carefully chosen nutrients, each playing a vital role in supporting your pregnancy journey. We believe in educating you about these choices, helping you understand why each nutrient is crucial for you and your baby.
                        </p>
                        <!-- <button class="about-btn">Let's Get In Touch</button> -->
                    </div>
                    <!-- mobile view -->
                    <!-- <img src="<?php echo base_url(); ?>images/icons/pregnant-woman.png"
                        class="img-fluid  d-flex d-lg-none" /> -->
                </div>
            </div>
        </div>
    </div>
</section>
<section class="About sec-5 mt-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="head">
                    <h3>Quality at Every Step: Our Commitment to Excellence</h3>
                    <div class="d-flex-head">
                        <p class="title">Honesty in Our Process:</p>
                        <!-- <img src="<?php echo base_url(); ?>images/icons/Component-3.png" /> -->
                    </div>
                    <div class="content-2">
                        <p>Quality is not just a word for us; it's our ethos. Our facility meets or exceeds Good Manufacturing Practices (GMP) standards. Each ingredient is carefully processed to retain its nutrient potency, ensuring that what you receive is nothing but the best. Our commitment to high-quality, organic sourcing and meticulous manufacturing guarantees that every capsule you take is safe, effective, and pure.
                        </p>
                        <!-- <button class="about-btn">Read More</button> -->
                    </div>
                </div>
            </div>
            <!-- <div class="col-md-5 col-sm-12">
                <div class="sec-5-col-2">
                    <div>
                        <h1>10</h1>
                        <h4>Countries</h4>
                    </div>
                    <div>
                        <h1>5</h1>
                        <h4>Countinents</h4>
                    </div>

                </div>
            </div> -->
        </div>
    </div>
</section>
<section class="About sec-6 mt-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-7 col-sm-12">
                <div class="About-img sec-6-img">
                    <!-- mobile view -->
                    <img src="<?php echo base_url(); ?>images/icons/sec-4-abt.png"
                        class="img-fluid  sec-4-img d-flex d-lg-none" />
                </div>
                <div class="head">
                    <h3>Organic Ingredients From Mother Earth</h3>
                    <div class="d-flex-head">
                        <p class="title">Sourced from the Earth, for You</p>
                        <img src="<?php echo base_url(); ?>images/icons/Component-1.png"
                            class="d-none d-lg-block" />
                    </div>
                    <div class="content-3">
                        <p>
                            Vitabae's journey begins in the lush fields of our trusted farm partners. Here, we meticulously select organic ingredients that are not just natural but also effective. Our farmers use sustainable practices to ensure that every harvest yields the purest ingredients, keeping your well-being and the environment in mind.
                        </p>
                        <!-- <button class="about-btn">Let's Get In Touch</button> -->
                    </div>
                </div>
            </div>
            <div class="col-md-5 col-sm-12 desktop-tab-banner">
                <div class="About-img sec-6-img">
                    <!-- desktop view -->
                    <img src="<?php echo base_url(); ?>images/icons/sec-4-abt.png"
                        class="img-fluid  sec-4-img   d-none d-lg-block" />
                </div>
            </div>
        </div>
    </div>
</section>
<section class="d-lg-none desktop-tab-banner">
    <img src="<?php echo base_url(); ?>images/icons/QUALITY.png" class="img-fluid" />
</section>
<section class="About sec-7 mt-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-7 col-sm-12">
                <div class="head">
                    <h3>Quality Matters</h3>
                    <div class="content">
                        <p>Nature's gifts play a crucial role in supporting you during this extraordinary journey into
                            motherhood, and we believe that purity and quality should never be compromised. Our promise
                            to you is a supplement crafted with the utmost care, free from synthetic additives,
                            pesticides, and harmful chemicals.
                        </p>
                        <!-- <a class="about-btn">Read More</button> -->
                    </div>
                </div>
            </div>
            <div class="col-md-5 col-sm-12">
                <div class="sec-5-col-2">

                </div>
            </div>
        </div>
    </div>
</section>
<script>
        // Change the title based on some condition or event
        document.getElementById("pageTitle").innerText = "About Us";
    </script>
<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>