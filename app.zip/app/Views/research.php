<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img src="<?php echo base_url(); ?>images/banner/contact-banner.png" class="img-fluid" alt="Vitabae supplement in a sustainable container with a minimalist design."/>
            </div>
            <div class="col-md-6">
                <div class="contact-banner ">
                    <h1>HOW WE BUILD</h1>
                    <h2>Vitabae</h2>
                    <div class="contact-o-para d-none d-lg-block">
                        <div class="contact-banner-content">
                            <p class="menu">1</p>
                            <h3>Our Commitment to Transparency</h3>
                            <p>We believe in complete transparency about our ingredients and manufacturing process.
                                Using only carefully selected organic ingredients, sourced from trusted farms,
                                prioritizing organic & sustainable practices. Our manufacturing process, takes place in
                                state-of-the-art facilities that adhere to the strictest standards.</p>
                        </div>
                        <div class="contact-banner-content">
                            <p class="menu">2</p>
                            <h3>Science-Backed Formulation You Can Trust</h3>
                            <p>Trust is the foundation of our relationship with you. Vitabae's prenatal supplements are
                                formulated based on scientific research. Our experts ensures that each ingredient
                                contributes to the health and well-being of both mother and child.</p>
                        </div>
                        <div class="contact-banner-content">
                            <p class="menu">3</p>
                            <h3>Honesty in Quality and Manufacturing</h3>
                            <p>Quality is not just a promise; it's a guarantee. We source high-quality, organic
                                ingredients and process them in facilities that meet or exceed Good Manufacturing
                                Practice standards. Our process, from washing and blanching to juicing and drying, is
                                designed to retain the potency of nutrients.</p>
                        </div>
                        <div class="contact-banner-content">
                            <p class="menu">4</p>
                            <h3>Educating on Our Formulation</h3>
                            <p>Understanding our formulation is key to appreciating its benefits. Each ingredient in our
                                supplement is chosen for its role in supporting pregnancy. Our process, involving steps
                                like filtering, freeze-drying, and grinding, is perfected to maintain the integrity of
                                these ingredients. Our capsule filling process is meticulous, ensuring consistency &
                                quality.
                            </p>
                            <p class="menu-bottom"></p>
                        </div>
                    </div>
                </div>
                <div class="contact-banner d-lg-none">
                 
                    <div class="banner-tab">
                        <ul class="nav nav-tabs" id="myTabbanner" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                                    data-bs-target="#home" type="button" role="tab" aria-controls="home"
                                    aria-selected="true">1</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile"
                                    type="button" role="tab" aria-controls="profile" aria-selected="false">2</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact"
                                    type="button" role="tab" aria-controls="contact" aria-selected="false">3</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contact-tab" data-bs-toggle="tab"
                                    data-bs-target="#education" type="button" role="tab" aria-controls="contact"
                                    aria-selected="false">4</button>
                            </li>
                        </ul>
                        <span></span>
                        <div class="tab-content" id="myTabContent-banner">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <div class="contact-banner-content">
                                    <p class="menu">1</p>
                                    <h3>Our Commitment to Transparency</h3>
                                    <p>We believe in complete transparency about our ingredients and manufacturing
                                        process. Using only carefully selected organic ingredients, sourced from trusted
                                        farms, prioritizing organic & sustainable practices. Our manufacturing process,
                                        takes place in state-of-the-art facilities that adhere to the strictest
                                        standards.</p>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <div class="contact-banner-content">
                                    <p class="menu">2</p>
                                    <h3>Science-Backed Formulation You Can Trust</h3>
                                    <p>Trust is the foundation of our relationship with you. Vitabae's prenatal
                                        supplements are formulated based on scientific research. Our experts ensures
                                        that each ingredient contributes to the health and well-being of both mother and
                                        child.</p>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                                <div class="contact-banner-content">
                                    <p class="menu">3</p>
                                    <h3>Honesty in Quality and Manufacturing</h3>
                                    <p>Quality is not just a promise; it's a guarantee. We source high-quality, organic
                                        ingredients and process them in facilities that meet or exceed Good
                                        Manufacturing Practice standards. Our process, from washing and blanching to
                                        juicing and drying, is designed to retain the potency of nutrients.</p>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="education" role="tabpanel" aria-labelledby="contact-tab">
                                <div class="contact-banner-content">
                                    <p class="menu">4</p>
                                    <h3>Educating on Our Formulation</h3>
                                    <p>Understanding our formulation is key to appreciating its benefits. Each
                                        ingredient in our supplement is chosen for its role in supporting pregnancy. Our
                                        process, involving steps like filtering, freeze-drying, and grinding, is
                                        perfected to maintain the integrity of these ingredients. Our capsule filling
                                        process is meticulous, ensuring consistency & quality.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="mb-5">
    <div class="contact-2-title">
        <h2>RESEARCH AND ARTICLES</h2>
    </div>
    <div class="blog">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-12">
                    <div class="title">
                        <h3>
                            Recent Blogs
                        </h3>
                        <p>Click here to discover information on maintaining a healthy and safe pregnancy.</p>
                        <a href="https://vitabae.com/blogs/index" class="d-none d-lg-block">Discover Wellness Insights</a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-12">
                    <div class="blog-owl">
                        <div class="owl-carousel">
                            <div class="item"><a href="https://vitabae.com/blogs/first-prenatal-visit"><img src="<?php echo base_url(); ?>images/icons/owl-caro-1.png"
                                    class="img-fluid" /></a></div>
                            <div class="item"><a href="https://vitabae.com/blogs/coping-with-miscarriage"><img src="<?php echo base_url(); ?>images/icons/owl-caro-2.png"
                                    class="img-fluid" /></a></div>
                            <!-- <div class="item"><img src="<?php echo base_url(); ?>images/icons/owl-caro-3.png"
            class="img-fluid" /></div> -->
                        </div>
                    </div>
                    <div class="title d-lg-none">
                        <a href="https://vitabae.com/blogs/index" class="">Read more</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- <div class="container-fluid">
        <div class="contact-2-content">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do.</p>
            <form>
                <input type="search" class="contact-2-search" placeholder="Search" />
                <button><img src="<?php echo base_url(); ?>images/icons/Search.png"></button>
            </form>
            <div class="contact-tabs">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#all"
                            type="button" role="tab" aria-controls="home" aria-selected="true">All</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#science"
                            type="button" role="tab" aria-controls="profile" aria-selected="false">Science</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#pregnancy"
                            type="button" role="tab" aria-controls="contact" aria-selected="false">Pregancy</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#babycare"
                            type="button" role="tab" aria-controls="profile" aria-selected="false">Baby care</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#foodhabits"
                            type="button" role="tab" aria-controls="contact" aria-selected="false">Food Habits</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#prenatalcare"
                            type="button" role="tab" aria-controls="contact" aria-selected="false">Prenatal -
                            care</button>
                    </li>
                </ul>
                <span></span>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="home-tab">
                        <div class="contact-tab-content-1">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="img-bg-contact-1">
                                        <div class="contact-bg-content">
                                            <h6>5 min Read</h6>
                                            <p>Lorem ipsum dolor sit amet consectetur adipiscing elit, sed do.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="img-bg-contact-2">
                                        <div class="contact-bg-content">
                                            <h6>5 min Read</h6>
                                            <p>Lorem ipsum dolor sit amet consectetur adipiscing elit, sed do.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="img-bg-contact-3">
                                        <div class="contact-bg-content">
                                            <h6>5 min Read</h6>
                                            <p>Lorem ipsum dolor sit amet consectetur adipiscing elit, sed do.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="contact-tab-more">
                                <a href="#" class="more">View All</a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="science" role="tabpanel" aria-labelledby="profile-tab">

                    </div>
                    <div class="tab-pane fade" id="pregnancy" role="tabpanel" aria-labelledby="contact-tab">

                    </div>
                    <div class="tab-pane fade" id="babycare" role="tabpanel" aria-labelledby="profile-tab">

                    </div>
                    <div class="tab-pane fade" id="foodhabits" role="tabpanel" aria-labelledby="contact-tab">

                    </div>
                    <div class="tab-pane fade" id="prenatalcare" role="tabpanel" aria-labelledby="contact-tab">

                    </div>
                </div>
            </div>
        </div>
    </div> -->
</section>
<section class="supplements ">
    <div class="container">
        <!-- <h2>
            NAM LIBERAO TEMPORE
        </h2>
        <p>Eget mi proin sed libero enim sed faucibus turpis. Nisl rhoncus mattis urna neque viverra justo. Vivamus at
            augue eget arcu dictum. Ultrices dictum fusce ut placerat orci. Aenean et tortor </p> -->
        <div class="supplements-details">
            <!-- <h6>View Supplement Facts</h6> -->
            <div class="d-none d-lg-block">
                <div class="row ">
                    <div class="col-md-4">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>LENTILS</h2>

                                <p>Lentils are a significant source of folate, containing ample amounts of this crucial
                                    B-vitamin.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#lentils">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="lentils" tabindex="-1" aria-labelledby="lentilsLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">LENTILS</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Plays a pivotal role in supporting the health and development of both
                                                the mother and crucial for DNA synthesis and cell division of the
                                                growing baby during pregnancy.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-1.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>BROCCOLI</h2>
                                <p>Broccoli is a powerhouse of nutrients, containing essential components such as
                                    folate, vitamin c and calcium.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#broccoli">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="broccoli" tabindex="-1" aria-labelledby="broccoliLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">BROCCOLI</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Eating broccoli during pregnancy provides crucial nutrients such as
                                                folate for neural tube development, vitamin C for immune support, and
                                                calcium for bone health, promoting overall maternal and fetal
                                                well-being.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-2.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="suppl-content-details ">
                            <div class="suppl-content">
                                <h2>AMLA</h2>
                                <p>Amla is rich in immune-boosting vitamin C, a key nutritional component that defines
                                    its health profile.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#amla">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="amla" tabindex="-1" aria-labelledby="amlaLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">AMLA</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Amla provides a powerhouse of benefits during pregnancy, including
                                                enhanced iron absorption, supporting immune system and crucial support
                                                for fetal development, making it an invaluable addition to maternal
                                                well-being.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-3.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="row mt-4">
                    <div class="col-md-4">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>BEETS</h2>
                                <p>Beets are rich in natural nitrates, a key nutritional component that defines their
                                    health profile.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#beets">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="beets" tabindex="-1" aria-labelledby="beetsLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">BEETS</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                These natural nitrates in beets support improved blood flow,
                                                contributing to enhanced cardiovascular health for both the expectant
                                                mother and the developing baby.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-4.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>GINGER</h2>
                                <p>Ginger contains active compounds such as gingerol and shogaol, contributing to its
                                    nutritional profile during pregnancy.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#ginger">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="ginger" tabindex="-1" aria-labelledby="gingerLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">GINGER</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                These compounds in ginger exhibit anti-nausea and anti-vomiting
                                                properties, providing relief from common discomforts associated with
                                                pregnancy.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-5.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="suppl-content-details ">
                            <div class="suppl-content">
                                <h2>GARLIC</h2>
                                <p>Garlic contains allicin, a potent active compound that contributes to its nutritional
                                    composition.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#garlic">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="garlic" tabindex="-1" aria-labelledby="garlicLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">GARLIC</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Allicin in garlic exhibits antimicrobial and anti-inflammatory
                                                properties, providing various health benefits, including immune support
                                                and inflammation reduction.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-6.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="row mt-4">
                    <div class="col-md-4">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>SPIRULINA</h2>
                                <p>Spirulina is rich in phytochemical compounds such as phycocyanin, chlorophyll, and
                                    beta-carotene</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#spirulina">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="spirulina" tabindex="-1" aria-labelledby="spirulinaLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">SPIRULINA</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                These compounds contribute to the overall health of both the expectant
                                                mother and the developing baby by providing antioxidant support, aiding
                                                in the prevention of oxidative stress-related issues, and promoting a
                                                well-rounded nutritional profile during pregnancy.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-7.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>SPINACH</h2>
                                <p>Spinach is a nutrient-rich green leafy vegetable, packed with essential vitamins and
                                    minerals.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#spinach">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="spinach" tabindex="-1" aria-labelledby="spinachLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">SPINACH</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Abundant in folate, iron, and other nutrients, spinach supports fetal
                                                development, helps prevent neural tube defects, and contributes to
                                                overall maternal health.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-8.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="suppl-content-details ">
                            <div class="suppl-content">
                                <h2>CURRY LEAVES</h2>
                                <p>Curry leaves are notably rich in iron, a vital mineral essential for various
                                    physiological functions.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#curry">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="curry" tabindex="-1" aria-labelledby="curryLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">CURRY LEAVES</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                It supports the prevention of iron-deficiency anemia. Adequate iron
                                                intake is crucial for maternal health, contributing to energy levels and
                                                overall well-being, while also supporting proper fetal development.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-9.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="carouselExampleControls" class="carousel slide d-lg-none" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>LENTILS</h2>

                                <p>Lentils are a significant source of folate, containing ample amounts of this crucial
                                    B-vitamin.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#lentils-sm">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="lentils-sm" tabindex="-1" aria-labelledby="lentils-smLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">LENTILS</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Plays a pivotal role in supporting the health and development of both
                                                the mother and crucial for DNA synthesis and cell division of the
                                                growing baby during pregnancy.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-1.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>BROCCOLI</h2>
                                <p>Broccoli is a powerhouse of nutrients, containing essential components such as
                                    folate, vitamin c and calcium.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#broccoli">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="broccoli" tabindex="-1" aria-labelledby="broccoliLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">BROCCOLI</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Eating broccoli during pregnancy provides crucial nutrients such as
                                                folate for neural tube development, vitamin C for immune support, and
                                                calcium for bone health, promoting overall maternal and fetal
                                                well-being.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-2.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>AMLA</h2>
                                <p>Amla is rich in immune-boosting vitamin C, a key nutritional component that defines
                                    its health profile.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#amla">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="amla" tabindex="-1" aria-labelledby="amlaLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">AMLA</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Amla provides a powerhouse of benefits during pregnancy, including
                                                enhanced iron absorption, supporting immune system and crucial support
                                                for fetal development, making it an invaluable addition to maternal
                                                well-being.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-3.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>BEETS</h2>
                                <p>Beets are rich in natural nitrates, a key nutritional component that defines their
                                    health profile.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#beets">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="beets" tabindex="-1" aria-labelledby="beetsLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">BEETS</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                These natural nitrates in beets support improved blood flow,
                                                contributing to enhanced cardiovascular health for both the expectant
                                                mother and the developing baby.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-4.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>GINGER</h2>
                                <p>Ginger contains active compounds such as gingerol and shogaol, contributing to its
                                    nutritional profile during pregnancy.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#ginger">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="ginger" tabindex="-1" aria-labelledby="gingerLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">GINGER</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                These compounds in ginger exhibit anti-nausea and anti-vomiting
                                                properties, providing relief from common discomforts associated with
                                                pregnancy.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-5.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="suppl-content-details ">
                            <div class="suppl-content">
                                <h2>GARLIC</h2>
                                <p>Garlic contains allicin, a potent active compound that contributes to its nutritional
                                    composition.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#garlic">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="garlic" tabindex="-1" aria-labelledby="garlicLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">GARLIC</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Allicin in garlic exhibits antimicrobial and anti-inflammatory
                                                properties, providing various health benefits, including immune support
                                                and inflammation reduction.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-6.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>SPIRULINA</h2>
                                <p>Spirulina is rich in phytochemical compounds such as phycocyanin, chlorophyll, and
                                    beta-carotene</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#spirulina">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="spirulina" tabindex="-1" aria-labelledby="spirulinaLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">SPIRULINA</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                These compounds contribute to the overall health of both the expectant
                                                mother and the developing baby by providing antioxidant support, aiding
                                                in the prevention of oxidative stress-related issues, and promoting a
                                                well-rounded nutritional profile during pregnancy.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-7.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="suppl-content-details">
                            <div class="suppl-content">
                                <h2>SPINACH</h2>
                                <p>Spinach is a nutrient-rich green leafy vegetable, packed with essential vitamins and
                                    minerals.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#spinach">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="spinach" tabindex="-1" aria-labelledby="spinachLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">SPINACH</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Abundant in folate, iron, and other nutrients, spinach supports fetal
                                                development, helps prevent neural tube defects, and contributes to
                                                overall maternal health.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-8.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="suppl-content-details ">
                            <div class="suppl-content">
                                <h2>CURRY LEAVES</h2>
                                <p>Curry leaves are notably rich in iron, a vital mineral essential for various
                                    physiological functions.</p>
                                <h4>
                                    India, Srilanka
                                </h4>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary benifits" data-bs-toggle="modal"
                                    data-bs-target="#curry">
                                    Benefits
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="curry" tabindex="-1" aria-labelledby="curryLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3 class="modal-title fs-5" id="exampleModalLabel">CURRY LEAVES</h3>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                It supports the prevention of iron-deficiency anemia. Adequate iron
                                                intake is crucial for maternal health, contributing to energy levels and
                                                overall well-being, while also supporting proper fetal development.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="suppl-image">
                                <img src="<?php echo base_url(); ?>images/icons/supplements-9.png" class="img-fluid">
                                <a href="#">+</a>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>

            <!-- <h4 class="ingrdients">See All INGREDIENTS</h4> -->
            <!-- <a href="#" class="img-fluid read-more-article">READ MORE ABOUT ARTICLE</a> -->
        </div>
    </div>
</section>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Change the title based on some condition or event
        document.getElementById('pageTitle').innerText = 'Vitabae Research: Science-Backed Insights for Pregnancy Wellness.';
        
        // Change the meta tags based on some condition or event
        document.getElementById('metatags').setAttribute('content', 'Explore Vitabae\'s blog and research for science-backed insights, expert advice, and practical tips to support you through every stage of pregnancy');
    });
</script>
<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>