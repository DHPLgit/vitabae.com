<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>

<section class="home">
    <!-- desktop -->
    <div class="container-fluid" style="padding: 0px !important;">
        <div id="carouselExampleCaptions" class="carousel slide ">
            
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?php echo base_url(); ?>images/banner/banner.webp" class="d-block d-none d-md-block w-100" alt="...">
                    <img src="<?php echo base_url(); ?>images/banner/md-banner.png" class="d-flex d-lg-none" alt="...">
                    <div class="carousel-caption ">
                        <h1><span>From Conception to Birth:</span><br /> Prenatal Nutrition for Healthy Beginnings </h1>
                        <p>Know What's in Your Prenatal: Choose <br />Transparency. Don’t Live In The
                            Unknown:<br />Your
                            Pregnancy
                            Deserves More</p>
                        <div class="postedIn d-none d-md-block">
                            <a href="" class="">Pre -Planning</a>&nbsp;
                            <a href="" class="">1st Trimester</a>&nbsp;
                            <a href="" class="">2nd Trimester</a>&nbsp;
                            <a href="" class="">3rd Trimester</a>&nbsp;
                            <a href="" class="">Post Pregnancy</a>&nbsp;
                        </div>
                        <div class="d-flex d-lg-none"><a href="" class="">Learn More </a></div>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev">
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next">
                <span class="visually-hidden">Next</span>
            </button>
        </div>
        <!-- mobile -->
        <!-- <div id="carouselExampleCaptions" class="carousel slide d-flex d-lg-none">
            <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?php echo base_url(); ?>images/banner/md-banner.png" class="" alt="...">
                    <div class="carousel-caption carousel-caption-md">
                        <h1><span>From Conception to Birth:</span><br /> Prenatal Nutrition for Healthy Beginnings </h1>
                        <p class="md">Know What's in Your Prenatal: Choose Transparency. Don’t Live In The Unknown:
                            Your
                            Pregnancy
                            Deserves More</p>
                        <div class=""><a href="" class="">Learn More </a></div>
                    </div>
                </div>
                <div class="carousel-item">
                                <img src="..." class="d-block w-100" alt="...">
                                <div class="carousel-caption d-none d-md-block">
                                <h5>Second slide label</h5>
                                <p>Some representative placeholder content for the second slide.</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="..." class="d-block w-100" alt="...">
                                <div class="carousel-caption d-none d-md-block">
                                <h5>Third slide label</h5>
                                <p>Some representative placeholder content for the third slide.</p>
                                </div>
                            </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div> -->
</section>
<section class="sec-2 ">
    <div class="container-fluid">
        <!-- mobile-view -->
        <div id="carouselExample" class="carousel slide d-lg-none">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="d-flex">
                        <div class="count-mb">
                            <div class="countmd-1">
                                <!-- <h3>01</h3> -->
                            </div>
                            <div class="d-flex justify-content-center count2md">

                                <h4>Organic Ingredients</h4>
                            </div>
                        </div>
                        <div class="count-mb">
                            <div class="countmd-2">
                                <!-- <h3>02</h3> -->
                            </div>
                            <div class="d-flex justify-content-center count2md">

                                <h4>Transparency</h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="d-flex">
                        <div class="count-mb">
                            <div class="countmd-3">
                                <!-- <h3>01</h3> -->
                            </div>
                            <div class="d-flex justify-content-center count2md">

                                <h4>Organic Ingredients</h4>
                            </div>
                        </div>
                        <div class="count-mb">
                            <div class="countmd-4">
                                <!-- <h3>02</h3> -->
                            </div>
                            <div class="d-flex justify-content-center count2md">

                                <h4>Transparency</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true">
                    <img src="<?php echo base_url(); ?>images/icons/arrow-small-left-2.png" alt="" />
                </span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true">
                    <img src="<?php echo base_url(); ?>images/icons/arrow-small-right-2.png" alt="" />
                </span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
        <!-- desktop view -->
        <div class="d-none d-lg-block">
            <div class="row ">
                <div class="col-md-3 col-sm-6">
                    <div class="count">
                        <!-- <h3>01</h3> -->
                    </div>
                    <div class="d-flex justify-content-center count2">
                        <!-- <img src="<?php echo base_url(); ?>images/icons/arrow-small-right-2.png" class="img-fluid" /> -->
                        <h4>Organic Ingredients</h4>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="count-1">
                        <!-- <h3>02</h3> -->
                    </div>
                    <div class="d-flex justify-content-center count2">
                        <!-- <img src="<?php echo base_url(); ?>images/icons/arrow-small-right-2.png" class="img-fluid" /> -->
                        <h4>Transparency</h4>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="count-2">
                        <!-- <h3>03</h3> -->
                    </div>
                    <div class="d-flex justify-content-center count2">
                        <!-- <img src="<?php echo base_url(); ?>images/icons/arrow-small-right-2.png" class="img-fluid" /> -->
                        <h4>Customization</h4>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="count-3">
                        <!-- <h3>04</h3> -->
                    </div>
                    <div class="d-flex justify-content-center count2">
                        <!-- <img src="<?php echo base_url(); ?>images/icons/arrow-small-right-2.png" class="img-fluid" /> -->
                        <h4>Crafted In-House</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="whoweare mt-2">
    <div class="container-fluid">
        <!-- desktop view -->
        <div class="d-none d-lg-block who-content">
            <div class="row ">
                <div class="col-lg-4 col-md-5 col-sm-6">
                    <div class="head">
                        <h2>Customize</h2>
                        <div class="d-flex ">
                            <p>Your Prenatal</p>
                            <!-- <img src="<?php echo base_url(); ?>images/icons/Component-1.png" /> -->
                            <div></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-7 col-sm-6">
                    <div class="head-2">
                        <p>We’ll work with you to create the perfect prenatal personalized to your exact needs based on
                            your stage of pregnancy.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- mobile view -->
        <div class="d-flex d-lg-none">
            <div class="head">
                <h3>Customize</h3>
                <div class="d-flex justify-content-between">
                    <p>Your Prenatal</p>
                    <div></div>
                </div>
            </div>
            <div class="head-2">
                <p>We’ll work with you to create the perfect prenatal personalized to your exact needs based on
                    your stage of pregnancy.
                </p>
            </div>
        </div>
    </div>
</section>
<section class="About mt-2">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 col-md-5">
                <div class="About-img">
                    <!-- desktop view -->
                    <img src="<?php echo base_url(); ?>images/banner/about-us-1.webp"
                        alt="Vitabae prenatal supplement bottle on a white background"
                        class="img-fluid  d-none d-lg-block" />
                    <!-- mobile view -->
                    <img src="<?php echo base_url(); ?>images/banner/about-us-md.webp"
                        alt="Medical professional with a writing pad smiling in front of a group of doctors."
                        class="img-fluid  d-flex d-lg-none" />
                </div>
            </div>
            <div class="col-lg-8 col-md-7">
                <div class="head">
                    <h2>About</h2>
                    <p class="title">What We Do</p>
                    <div class="content">
                        <p>Educating customers on product benefits, organic ingredients, and sustainability while
                            empowering them with accessible resources for informed health and environmental choices.</p>
                        <button (click)="loadTypeformScript()" class="about-btn" data-bs-toggle="modal"
                            data-bs-target="#send-mess">Take the First Step</button>

                        <!-- Modal -->
                        <div class="modal fade" id="send-mess" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div data-tf-live="01HKR5M3EDQN8045N0T90VSNP9"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="pay-us mt-5  d-none d-lg-block">
    <div class="container-fluid">
        <div class="content">
            <div class="row">
                <div class="col-md-4 col-sm-12">
                    <div class="d-flex justify-content-center bd-home-right">
                        <img src="<?php echo base_url(); ?>images/icons/Location-Icon.webp" class="img-fluid" />
                        <div class="content-title">
                            <h3>Pay Us a Visit</h3>
                            <p>Los Angeles California</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="d-flex justify-content-center bd-home-right">
                        <img src="<?php echo base_url(); ?>images/icons/phone-call.webp" class="img-fluid" />
                        <div class="content-title">
                            <!-- <h3>Give Us a Call</h3> -->
                            <h3>To Reach Us</h3>
                            <a class="reach-us" href="<?= base_url('/contact') ?>">Get in Touch</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="d-flex justify-content-center bd-last">
                        <img src="<?php echo base_url(); ?>images/icons/mail.webp" class="img-fluid" />
                        <div class="content-title">
                            <h3>Send Us a Message</h3>
                            <p>admin@vitabae.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="pay-us-md mt-5 d-flex d-lg-none">

    <div class="container">
        <div class="content">
            <div class="row">
                <div class="col-md-4 col-sm-12">
                    <div class=" bd-right">
                        <div class="content-inner">

                            <img src="<?php echo base_url(); ?>images/icons/Location-Icon.png" class="img-fluid" />
                            <div class="content-title">
                                <h3>Pay Us a Visit</h3>
                                <p>Los Angeles California</p>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class=" bd-right">
                        <div class="content-inner">
                            <img src="<?php echo base_url(); ?>images/icons/phone-call.png" class="img-fluid" />
                            <div class="content-title">
                                <!-- <h3>Give Us a Call</h3> -->
                                <h3>To Reach Us</h3>
                                <a class="reach-us" href="<?= base_url('/contact') ?>">Click Here</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class=" bd-right">
                        <div class="content-inner">

                            <img src="<?php echo base_url(); ?>images/icons/mail.png" class="img-fluid" />
                            <div class="content-title">
                                <h3>Send Us a Message</h3>
                                <p>admin@vitabae.com</p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class=" three-sec-bg mt-5 mb-5">
    <div class="container-fluid">
        <div class="lab">
            <div class="">
                <div class="welcome">
                    <h2>WELCOME TO OUR LAB</h2>
                    <div class="wel-btn">
                        <a href="<?= base_url('/research') ?>">
                            <img src="<?php echo base_url(); ?>images/icons/wel-btn.png" class="img-fluid" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="journey mt-5  d-none d-lg-block">
            <div class="">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="head">
                            <h3>Because Every Journey is Unique</h3>
                            <div class=" d-none d-lg-block">
                                <div class="d-flex justify-content-start">
                                    <!-- <p class="vitabae-title">VITABAE</p> -->
                                    <!-- <img src="<?php echo base_url(); ?>images/icons/Component-1.png" /> -->
                                </div>

                            </div>
                            <div class="journey-read-button d-none d-lg-block">
                                <a href="<?= base_url('/research') ?>" class="journey-read">Explore our Health
                                    Studies</a>
                            </div>
                            <div class=" d-lg-none">
                                <p class="vitabae-title">VITABAE</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-6 col-sm-12">
                        <div class="head-2">
                            <p>Embrace the unique journey of motherhood with our specialized prenatal solution. Vitabae
                                stands out in its commitment to customization. We understand that no two pregnancies are
                                the same, and our prenatal formula is crafted to address the challenges and requirements
                                often overlooked by other products. Join us in celebrating the distinctiveness of every
                                pregnancy; let our tailored prenatal care accompany you on this extraordinary journey.
                            </p>
                        </div>
                        <div class="journey-read-button  d-lg-none">
                            <a href="<?= base_url('/research') ?>" class="journey-read">Discover Wellness Insights</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="journey mt-5  d-lg-none">
            <div class="">
                <div class="row">
                    <div class="head">
                        <h3>Because Every Journey is Unique</h3>
                        <div class=" d-none d-lg-block">
                            <div class="d-flex justify-content-start">
                                <!-- <p class="vitabae-title">VITABAE</p> -->
                                <img src="<?php echo base_url(); ?>images/icons/Component-1.png" />
                            </div>

                        </div>
                        <div class=" d-lg-none">
                            <!-- <p class="vitabae-title">VITABAE</p> -->
                        </div>
                    </div>
                    <div class="head-2">
                        <p>Embrace the unique journey of motherhood with our specialized prenatal solution. Vitabae
                            stands out in its commitment to customization. We understand that no two pregnancies are
                            the same, and our prenatal formula is crafted to address the challenges and requirements
                            often overlooked by other products. Join us in celebrating the distinctiveness of every
                            pregnancy; let our tailored prenatal care accompany you on this extraordinary journey.
                        </p>
                    </div>
                    <div class="journey-read-button ">
                        <a href="<?= base_url('/research') ?>" class="journey-read">READ MORE</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="blog mb-5">
            <div class="">
                <div class="row">
                    <div class="col-md-3 col-sm-12">
                        <div class="title">
                            <h3>
                                Recent Blogs
                            </h3>
                            <p>Click here to discover information on maintaining a healthy and safe pregnancy.</p>
                            <a href="https://vitabae.com/blogs/index" class="d-none d-lg-block">Discover Wellness
                                Insights</a>
                        </div>
                    </div>
                    <div class="col-md-9 col-sm-12">
                        <div class="blog-owl">

                            <div class="owl-carousel">
                                <a href="https://vitabae.com/blogs/breastfeeding-tips">
                                    <div class="item"><img
                                            src="<?php echo base_url(); ?>images/icons/Edema-During-Pregnancy.webp"
                                            class="img-fluid" /></div>
                                </a>
                                <a href="https://vitabae.com/blogs/coping-with-miscarriage">
                                    <div class="item"><img
                                            src="<?php echo base_url(); ?>images/icons/pregnancy-cramps.webp"
                                            class="img-fluid" /></div>
                                </a>
                                <a href="https://vitabae.com/blogs/first-prenatal-visit">
                                    <div class="item"><img
                                            src="<?php echo base_url(); ?>images/icons/spinach-for-pregnant-women.webp"
                                            class="img-fluid" /></div>
                                </a>
                            </div>

                        </div>
                        <div class="title d-lg-none">

                            <a href="https://vitabae.com/blogs/index" class="">READ MORE</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- <div class="main-form">
            <div class="form ">
                <div class="container">
                    <h1>Join Vitabae</h1>
                    <img src="<?php echo base_url(); ?>images/icons/form-border.png" class="img-fluid" />
                    <h3>Let’s Build Our Products</h3>
                    <form class="home-form">
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" placeholder="First Name" id="firstname" autocomplete="given-name" />
                                <br />
                                <input type="email" placeholder="Email" id="email" autocomplete="email" />
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Last Name" id="lastname" autocomplete="family-name" />
                                <br />
                                <input type="tel" placeholder="Phone Number" id="phone" autocomplete="phone" />
                            </div>
                        </div>
                        <button type="submit">Send to Vitabae</button>

                    </form>
                </div>
            </div>
        </div> -->
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Change the title based on some condition or event
        document.getElementById('pageTitle').innerText = 'Vitabae: Transparent, Science-Backed Supplements for Every Stage of Motherhood.';

        // Change the meta tags based on some condition or event
        document.getElementById('metatags').setAttribute('content', 'Discover Vitabae\'s science-backed, transparent prenatal supplements made with whole food ingredients and third-party certifications for the health of you and your baby.');
    });
</script>


<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>