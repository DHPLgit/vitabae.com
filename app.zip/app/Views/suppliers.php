<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>
<section class="farmer-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-12 suppliers-dnone">
                
            <img src="<?php echo base_url(); ?>images/banner/farmer-banner-sm.png" class="img-fluid d-lg-none" alt="Elderly farmer wearing a straw hat, carrying organic produce in a handmade basket."/>
                <div class="join-banner-content">
                    <h1>Our <span>Trusted</span> Suppliers</h1>
                    <p>At Vitabae, we highly value our partnership with farmers, as it's the foundation of our
                        commitment to quality and sustainability. Learn how our farming practices ensure top-quality
                        ingredients in every Vitabae supplement.</p>
                    <button (click)="loadTypeformScript()" class="btn signup" data-bs-toggle="modal" data-bs-target="#signup">Sign up</button>
                    <!-- Modal -->
                    <div class="modal fade" id="signup" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div data-tf-live="01HKR5M3EDQN8045N0T90VSNP9"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <img src="<?php echo base_url(); ?>images/banner/farmer-banner.png" class="img-fluid  d-none d-lg-block" alt="Elderly farmer wearing a straw hat, carrying organic produce in a handmade basket."/>
                
            </div>
        </div>
    </div>
</section>
<section class="case-studies">
    <div class="container">
        <div class="case-studies-content">
            <p>At Vitabae, we highly value our partnership with farmers, as it forms the foundation of our commitment to quality and sustainability. Our relationships are built on mutual trust, respect, and a shared dedication to sustainable farming practices that not only protect the environment but also ensure the highest quality ingredients for our products.</p><p>
Ingredient traceability is at the core of what we do. Every expecting mother has the right to know where her supplements come from. Our farmers work tirelessly to cultivate ingredients in a manner that is both ethical and transparent, allowing us to trace each component from seed to supplement. This traceability ensures that every Vitabae product is crafted with integrity and meets the highest standards of safety and quality.</p><p>
We take pride in working with farmers who share our values of transparency, sustainability, and quality. By supporting organic and environmentally friendly farming methods, we help ensure that the soil remains healthy and that natural ecosystems thrive. This focus on sustainability not only supports the environment but also results in ingredients that are rich in nutrients and free from harmful chemicals.</p><p>
At Vitabae, our partnerships go beyond business transactions. We foster genuine, personal relationships with our farmers, understanding their challenges and supporting their growth. This human connection is what allows us to create supplements that are not only scientifically sound but also ethically sourced. By working directly with the people who grow our ingredients, we maintain full visibility over every step of the production process, guaranteeing that our customers receive supplements they can trust.
Learn how our commitment to sustainable practices and our relationships with dedicated farmers ensure that each Vitabae supplement is crafted with care, quality, and the utmost transparency.
</p>
        </div>
    </div>
</section>
<section class="farmer-why">
    <div class="container-fluid">
        <h2>Why Partner With <span> Vitabae Labs </span></h2>
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <div class="farmer-why-content-1">
                    <h4>Market Access</h4>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="farmer-why-content-2">
                    <h4>Innovation</h4>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <div class="farmer-why-content-3">
                    <h4>Expertise</h4>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="farmer-why-content-4">
                    <h4>Long-term
                        Partnership</h4>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="case-studies">
    <div class="container">
        <div class="case-studies-content">
            <h2>Read Our Case Studies</h2>
            <p>Discover the success stories behind our collaborations with industry partners. Explore how Vitabae's
                commitment to innovation and partnership has led to outstanding results. Dive into our case studies to
                learn more about our journey towards excellence.</p>
            <button class="btn">Read more</button>
        </div>
    </div>
</section>
<section class="que">
    <div class="container">
        <div class="que-content">
            <h2>Questions?</h2>
            <p>We have answers! Check out our handy FAQ for
                insights and info on all things vitabae</p>
            <div class="d-flex justify-content-center">
                <a href="<?= base_url('/contact') ?>" class="">Open the FAQ’s</a>
                <img src="<?php echo base_url(); ?>images/icons/farmer-arrow.png" class="img-fluid" />
            </div>
        </div>
    </div>
</section>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Change the title based on some condition or event
        document.getElementById('pageTitle').innerText = 'Vitabae Suppliers | Partnering with Real Farmers for Wellness';
        
        // Change the meta tags based on some condition or event
        document.getElementById('metatags').setAttribute('content', 'Vitabae partners with organic farmers, ensuring a transparent, ethical relationship that supports sustainable agriculture and premium ingredient quality.');
    });
</script>
<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>