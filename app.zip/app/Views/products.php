<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>
<section class="product">
    <div class="container">
        <div class="row">
            <!-- <img src="../../images/banner/product-banner.png"/> -->
            <h1><img src="<?php echo base_url(); ?>images/banner/product-banner.png"/ class="img-fluid" alt="We are launching soon"></h1>

            <p class="product-title">We are just a few days from our big launch. Sign up to be notified!</p>
            <form class="product-form">
                <input type="email" placeholder="Please enter your email address" class="email"/><br/>
                <button type="submit" class="btn">Notify me</button>
            </form>
            <div class="prdt-detail">
            
            
            <p>Experience the Vitabae difference—where <b>whole food ingredients, traceability, third-party certifications, and an uncompromising commitment to science and your health</b> converge to create prenatal supplements that transcend expectations. Vitabae, a privately owned company, is dedicated to ensuring that every product we make is as pure and effective as possible, driven by a commitment to rigorous scientific standards and innovative practices. Your pregnancy deserves nothing less than the quality and purity Vitabae provides.</p>
            <p>Vitabae supplements contain <b>no synthetics, no artificial flavors, no colorings, binders, or fillers.</b>Our products are crafted with an unwavering dedication to what matters most—providing essential nutrition without compromise. Each ingredient is carefully chosen, with full transparency and traceability from the source to the final product. We work only with trusted suppliers to ensure that every component meets our exacting standards.</p>
<p>Our commitment to science sets us apart. Backed by cutting-edge research and formulated with care, our supplements are designed to support both mother and baby throughout every stage of pregnancy. We understand the challenges of expecting mothers and the importance of proper nutrition during this critical time. That is why we emphasize whole food ingredients—to deliver nutrients in their most natural, bioavailable forms, ensuring optimal absorption and effectiveness.</p>
<p>
Traceability is at the core of our philosophy. We believe that expecting mothers have the right to know where their supplements come from and how they are made. From farm to capsule, our ingredients are fully traceable, allowing us to guarantee quality at every step of the process. This dedication to transparency is also reflected in our third-party certifications, which provide added assurance that our products are free from contaminants and meet the highest standards of purity and safety.
</p>
        </div>
        </div>
    </div>
</section>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Change the title based on some condition or event
        document.getElementById('pageTitle').innerText = 'Vitabae Products: Whole Food Ingredients, Traceability, Third-Party Certified.';
        
        // Change the meta tags based on some condition or event
        document.getElementById('metatags').setAttribute('content', 'Discover Vitabae\'s products made with whole food ingredients, traceability, and third-party certifications to ensure the highest quality for your health.');
    });
</script>

<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>