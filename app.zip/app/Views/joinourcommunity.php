<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>

<div #scrolleres><section class="community-banner">
    <div class="container">
        <div class="community-banner-content">
            <h1>Join Our<br/><span>Prenatal Wellness</span><br/>Community</h1>
            <p>Welcome to Vitabae's prenatal community. Join us for expert advice, exclusive content, and a supportive network of expectant mothers. Together, we'll ensure a healthy pregnancy journey for you and your baby.</p>
            <a class="btn" href="https://www.facebook.com/groups/235593375864742">Join now</a>
        </div>
    </div>
</section>
<section class="waiting">
    <div class="container">
<!--        <div class="waiting-content">-->
<!--            <p> Our mission is straightforward yet impactful: to establish a nurturing community where expecting mothers can find solace, information, and a sense of belonging. Pregnancy is a time filled with excitement, anticipation, and questions. At Vitabae, we understand the importance of providing comprehensive support, ensuring every woman has the resources she needs for an empowered experience.</p>-->

<!--<p>We believe that expecting mothers deserve more than just medical advice. They need a supportive environment where they can share experiences, ask questions, and connect with others on the same path. Vitabae is committed to creating a safe space where mothers can access expert advice, reliable information, and a network of individuals who understand their needs. This community is about providing emotional support as well as educational content that is both practical and empowering.</p>-->

<!--<p>Our approach is rooted in the understanding that pregnancy is not just about physical changes but also about mental and emotional well-being. By bringing together a diverse group of mothers, experts, and advocates, we aim to build a resource-rich community that offers guidance at every step. We provide content that addresses the various challenges of pregnancy while celebrating its moments of joy and transformation.</p>-->

<!--<p>The Vitabae community is here to bridge the gap between medical information and the lived experiences of mothers. By offering reliable resources, engaging discussions, and real stories, we ensure that mothers feel informed, confident, and never alone. Our goal is to foster an environment that respects every individual's experience, offering support that goes beyond the typical into the meaningful.</p>-->

<!--<p>With Vitabae, expecting mothers can be assured they are part of a community that truly understands them—one that values their health, well-being, and peace of mind. Together, we can navigate the complexities of pregnancy with the support, knowledge, and camaraderie that every mother deserves.</p>-->

<!--        </div>-->
    </div>
</section>
<section class="community-benefit">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="community-benefit-img-1 d-lg-none">
                    <img src="<?php echo base_url(); ?>images/icons/community-4.png" class="img-fluid"/>
                </div>
                <div class="community-benefit-content-1">
                    <h2>Benefits for<br/><span>Pregnant<br/>Women</span></h2>
                    <p>Access to Pregnancy Resources</p>
                    <p>Peer Support and Belonging</p>
                    <p>Expert Advice and Information</p>
                    <p>Exclusive Discounts on Prenatal Supplements</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="community-benefit-img-1 d-none d-lg-block">
                    <img src="<?php echo base_url(); ?>images/icons/community-4.png" class="img-fluid"/>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="community-benefit">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="community-benefit-img-2">
                    <img src="<?php echo base_url(); ?>images/icons/community-3.png" class="img-fluid"/>
                </div>
            </div>
            <div class="col-md-6">
                <div class="community-benefit-content-2">
                    <h2>Our<br/><span>Mission</span></h2>
                    <p>Our mission is simple but profound  to create a nurturing community where expecting mothers can celebrate their pregnancy journey. We believe that every woman deserves access to support, information, and a network of like-minded individuals during this special time.</p>
                </div>
            </div>  
        </div>
    </div>
</section>
<section class="community-benefit">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="community-benefit-img-1 d-lg-none">
                    <img src="<?php echo base_url(); ?>images/icons/community-2.png" class="img-fluid"/>
                </div>
                <div class="community-benefit-content-1">
                    <h2>Community<br/><span>Activities</span></h2>
                    <p>Prenatal Classes</p>
                    <p>Online Support Groups</p>
                    <p>Informative Webinars</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="community-benefit-img-1 d-none d-lg-block">
                    <img src="<?php echo base_url(); ?>images/icons/community-2.png" class="img-fluid"/>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="community-benefit">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="community-benefit-img-2">
                    <img src="<?php echo base_url(); ?>images/icons/community-1.png" class="img-fluid"/>
                </div>
            </div>
            <div class="col-md-6">
                <div class="community-benefit-content-2">
                    <h2> Resources &<br/><span>Support</span></h2>
                    <p>Informative Articles</p>
                    <p>Expert Advice</p>
                    <p>Trusted Prenatal Supplements</p>
                </div>
            </div>  
        </div>
    </div>
</section>
<section class="aspart">
    <div class="container-fluid">
        <div class="aspart-banner">
            <div class="aspart-content">
                <h2>Be a part of this community & create a better future</h2>
                <div class="row">
                    <div class="col-md-1">
                        
                    </div>
                    <div class="col-md-2">
                        <div class="aspart-count">
                            <h3>100+</h3>
                            <p>Happy Farmers</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="aspart-count">
                            <h3>600+</h3>
                            <p>Organic Food Grown</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="aspart-count">
                            <h3>900+</h3>
                            <p>Happy Families</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="aspart-count">
                            <h3>300+</h3>
                            <p>Toxic-Free Products</p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="aspart-count">
                            <h3>200+</h3>
                            <p>Happy Farmers</p>
                        </div>
                    </div>
                    <div class="col-md-1">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="waiting">
    <div class="container">
        <div class="waiting-content">
            <h2>So what are you waiting for?</h2>
            <p>Ready to embark on your wellness journey? Become a part of our vibrant Prenatal Wellness Community and embrace the joy of pregnancy with open arms.</p>
            <a class="btn" href="https://www.facebook.com/groups/235593375864742">Join now</a>
        </div>
    </div>
</section>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Change the title based on some condition or event
        document.getElementById('pageTitle').innerText = 'Vitabae Community: Empowering Expecting Mothers with Support & Care';
        
        // Change the meta tags based on some condition or event
        document.getElementById('metatags').setAttribute('content', 'Join the Vitabae community for pregnancy support, expert advice, and real stories from moms. Empower yourself through every stage of pregnancy.');
    });
</script>


<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>