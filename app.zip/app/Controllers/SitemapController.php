<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Sitemap extends CI_Controller {
    public function index() {
        header("Content-Type: application/xml; charset=utf-8");
        echo $this->load->view('sitemap', [], true);
    }
}

