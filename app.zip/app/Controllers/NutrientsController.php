<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use PHPMailer\PHPMailer\Exception;

use App\Models\PregnancyMcgModel;
use App\Models\LactatingMcgModel;
use App\Models\FemaleMcgModel;
use App\Models\MaleMcgModel;

class NutrientsController extends BaseController
{

    public function nutrients()
    {
        return view('nutrients');
    }

    protected $PregnancyMcgModel;
    protected $LactatingMcgModel;
    protected $FemaleMcgModel;
    protected $MaleMcgModel;

    public function __construct()
    {
        $this->PregnancyMcgModel = new PregnancyMcgModel();
        $this->LactatingMcgModel = new LactatingMcgModel();
        $this->FemaleMcgModel = new FemaleMcgModel();
        $this->MaleMcgModel = new MaleMcgModel();
    }

    public function getAllNutritionData()
    {
        try {
            // Get input data//
            
            $input = $this->request->getJSON();
             
            $age = $input->age ;
            $nutrientId = $input->nutrient_id ;
            $stage = strtolower($input->stage );
            $validNutrientIds = [1, 2, 3];
            // Validate input
            if (!$age || !$nutrientId || !$stage) {           // 

               // http_response_code(400); // Bad Request
                echo json_encode(['error' => 'Age, Nutrient_id, and stage are required.']);
                exit(); // Stop further execution
            }

            if (!in_array($nutrientId, $validNutrientIds)) {
                http_response_code(422); // Unprocessable Entity
                echo json_encode(['error' => 'Invalid Nutrient_id. Valid values are: 1 (Vitamins), 2 (Minerals), 3 (Both).']);
                exit(); // Stop further execution
            }


            // Determine nutrient IDs to query (if '3', use both 1 and 2)
            $nutrientIdsToQuery = ($nutrientId == 3) ? [1, 2] : [$nutrientId];

            // Handle Age validation (string or numeric)
            $ageColumn = null; // Default value for age column

            if (strpos($age, '-') !== false) {
                // Age range (e.g., '19-30')
                $validAges = [
                    '14-18' => '14to18',
                    '19-30' => '19to30',
                    '31-50' => '31to50',
                    '50-70' => '50to70',
                    '70+' => '70plus'
                ];
                // If the stage is male or female (non-pregnant), reject the age range
                if (in_array($stage, ['male', 'female'])) {
                    http_response_code(422); // Unprocessable Entity
                    echo json_encode(['error' => 'Invalid age range provided for male or non-pregnant stage. Please provide a specific numeric age instead of a range.']);
                    exit(); // Stop further execution
                }

                // If the age is a range but for a trimester or lactating stage, continue processing
                if (!array_key_exists($age, $validAges)) {
                    http_response_code(422); // Unprocessable Entity
                    echo json_encode(['error' => 'Invalid AGE range provided. Valid ranges are: ' . implode(', ', array_keys($validAges)) . '.']);
                    exit(); // Stop further execution
                }


                $ageColumn = $validAges[$age]; // Use the mapped column for the age range

            } elseif (is_numeric($age) && $age >= 2 && $age <= 120) {
                // Specific age (e.g., '25')
                // Determine the age column based on the age range
                if ($age >= 2 && $age <= 3)
                    $ageColumn = '2to3';
                elseif ($age >= 4 && $age <= 8)
                    $ageColumn = '4to8';
                elseif ($age >= 9 && $age <= 13)
                    $ageColumn = '9to13';
                elseif ($age >= 14 && $age <= 18)
                    $ageColumn = '14to18';
                elseif ($age >= 19 && $age <= 30)
                    $ageColumn = '19to30';
                elseif ($age >= 31 && $age <= 50)
                    $ageColumn = '31to50';
                elseif ($age >= 50 && $age <= 70)
                    $ageColumn = '50to70';
                elseif ($age >= 70)
                    $ageColumn = '70plus';
                // If the stage is Trimester, we require an age range like "19-30", not a single numeric age
                // Check if the stage contains 'trimester' and age is not a range
                if (strpos($stage, 'trimester') !== false && strpos($age, '-') === false) {
                    http_response_code(422); // Unprocessable Entity
                    echo json_encode(['error' => 'Age range is required for Trimester stage, not a single numeric age.']);
                    exit(); // Stop further execution
                }

                // Check if the stage contains 'months' and age is not a range
                if (strpos($stage, 'months') !== false) {
                    http_response_code(422); // Unprocessable Entity
                    echo json_encode(['error' => 'Age range is required for Lactating stage, not a single numeric age.']);
                    exit(); // Stop further execution
                }

                // If no valid age column is found
                if (!$ageColumn) {
                    http_response_code(422); // Unprocessable Entity
                    echo json_encode(['error' => 'Age is out of valid range.']);
                    exit(); // Stop further execution
                }

            } else {
                http_response_code(422); // Unprocessable Entity
                echo json_encode(['error' => 'Invalid AGE provided.']);
                exit(); // Stop further execution
            }

            // Handle Pregnancy, Lactating, or Non-pregnant logic
            if (strpos($stage, 'trimester') !== false) {
                // Pregnancy related
                if (!in_array($stage, ['1st_trimester', '2nd_trimester', '3rd_trimester'])) {
                    http_response_code(422); // Unprocessable Entity
                    echo json_encode(['error' => 'Invalid stage for pregnancy. Valid values are "1st_trimester", "2nd_trimester", or "3rd_trimester".']);
                    exit();
                }
            
                // **Trimester** stages are expected to be age ranges like '14-18', '19-30', etc.
                // If the age is not a range (does not contain a hyphen), throw an error.
                if (strpos($age, '-') === false) {
                    http_response_code(422); // Unprocessable Entity
                    echo json_encode(['error' => 'Age range is required for Trimester stage, not a single numeric age.']);
                    exit();
                }
            
                // Fetch the data from the model
                $details = $this->PregnancyMcgModel
                    ->select("Nutrients AS x, Source_Of_Goal AS 'Source of Goal', $stage AS Value")
                    ->where('AGE', $age)
                    ->whereIn('Nutrient_id', $nutrientIdsToQuery)
                    ->findAll();
            }
            elseif (strpos($stage, 'months') !== false) {
                // Lactating related
                $validLactatingColumns = [
                    '0-6 months' => 'oto6_months',
                    '7-12 months' => '7to12_months'
                ];

                if (!array_key_exists($stage, $validLactatingColumns)) {
                    echo json_encode(['error' => 'Invalid Lactating stage specified. Valid values are "0-6 months" or "7-12 months".'], 422); // Unprocessable Entity
                }

                $lactatingColumn = $validLactatingColumns[$stage];

                $details = $this->LactatingMcgModel
                    ->select("Nutrients AS x, Source_Of_Goal AS 'Source of Goal', $lactatingColumn AS Value")
                    ->where('AGE', $age)
                    ->whereIn('Nutrient_id', $nutrientIdsToQuery)
                    ->findAll();
            } else {
                // Non-pregnant (either male or female)
                if (strpos($age, '-') !== false) {
                    echo json_encode(['error' => 'Age range is not allowed for non-pregnant stage. Please provide a specific numeric age.'], 422); // Unprocessable Entity
                }

                $model = ($stage === 'male') ? $this->MaleMcgModel : $this->FemaleMcgModel;
try{
                $details = $model
                    ->select("Nutrients AS x, Source_Of_Goal AS 'Source of Goal', $ageColumn AS Value")
                    ->whereIn('Nutrient_id', $nutrientIdsToQuery)
                    ->findAll();
}catch(\Exception $e){
     echo $e->getMessage();exit;
}
                    
            }

            // Check if the query returned any results
            // if (empty($details)) {
            //     $response = [
            //         'status' => 'error',
            //         'message' => 'No data found for the given criteria.'
            //     ];
            //     http_response_code(404); // Not Found
            // } else {
            //     $response = [
            //         'status' => 'success',
            //         'data' => $details
            //     ];
            //     http_response_code(200); // OK
            // }

            // // Set the header for JSON response and output the data
            // header('Content-Type: application/json');
            // echo json_encode($response);


            if (empty($details)) {
                http_response_code(404); // Not Found
                header('Content-Type: application/json');
                echo json_encode(["message" => "No data found for the given criteria."]);
            } else {
                http_response_code(200); // OK
                header('Content-Type: application/json');
                echo json_encode($details); // Send $details directly
            }

        } catch (\Exception $e) { print_r($e);exit;
            // Handle any exceptions
            $response = [
                'status' => 'error',
                'message' => 'An error occurred: ' . $e->getMessage()
            ];
            http_response_code(500); // Internal Server Error
            header('Content-Type: application/json');
            echo json_encode($response);
        }
    }

}


// http://localhost:8001/nutritionData
